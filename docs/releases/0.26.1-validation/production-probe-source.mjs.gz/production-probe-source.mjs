// Intentional transport-failure test of the actual production page and worker.
// No response is replaced with inference, and no model weights may be downloaded.
import {strict as assert} from 'node:assert';
import {createServer} from 'node:http';
import {createReadStream} from 'node:fs';
import {readFile,writeFile,mkdir,cp,stat} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '@playwright/test';

const root=resolve(import.meta.dirname,'../..'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifestBytes=await readFile(resolve(root,'public/core-benchmark-v026/manifest.json'));
const manifest=JSON.parse(manifestBytes),sample=manifest.cases.find(c=>c.id==='case-01');
assert.equal(manifest.cases.length,40);assert.equal(sha(manifestBytes),'b61549c3de8714e2f015056276efc23dfb3c6f3e1206fbd6611b68af3712c391');
const sampleBytes=await readFile(resolve(root,'public/core-benchmark-v026',sample.image));
assert.equal(sha(sampleBytes),sample.sha256);assert.equal(sampleBytes.readUInt32BE(16),512);assert.equal(sampleBytes.readUInt32BE(20),512);
if(process.argv.includes('--prepare-check')){console.log(JSON.stringify({status:'prepared',browsersLaunched:0,networkRequests:0,caseId:sample.id,imageSha256:sample.sha256}));process.exit(0)}
assert(process.argv.includes('--build-ready'),'Execution requires an explicit parent build-ready signal and --build-ready.');
const attempt=process.argv.find(x=>x.startsWith('--attempt='))?.slice(10)??'attempt-01';assert(/^[a-z0-9-]+$/.test(attempt));
const outRoot='/tmp/geomodel3d-v0261-probe';await mkdir(outRoot,{recursive:true});const out=resolve(outRoot,attempt);await mkdir(out);
const snapshot=resolve(out,'build');await cp(resolve(root,'dist'),snapshot,{recursive:true,force:false,errorOnExist:true});
assert.equal(sha(await readFile(resolve(snapshot,'core-benchmark-v026/manifest.json'))),sha(manifestBytes));
const pkg=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));assert.equal(pkg.version,'0.26.1');
const repo='onnx-community/Qwen3.5-0.8B-ONNX-OPT',revision='9a4c21d8f724176b0a7edaaed36303044451886e';
const modelPrefix=`/${repo}/resolve/${revision}/`,target='preprocessor_config.json';
const report={format:'geomodel3d-production-negative-network-probe',version:1,appVersion:pkg.version,status:'preparing',startedAt:new Date().toISOString(),
 scope:'Intentional network failure in actual production page/worker on Chromium SwiftShader. No inference, weights, Safari, physical iPhone or quality/performance qualification.',
 failureInjection:{kind:'Playwright request.abort',errorCode:'failed',resource:target,pinnedRevision:revision},selectedCaseId:sample.id,imageSha256:sample.sha256,
 browser:'Chromium with SwiftShader software WebGPU',physicalDeviceVerified:false,network:[],localRequests:[],blockedRequests:[],workerEvents:[],pageErrors:[],consoleErrors:[],assets:[],checks:[]};
const record=()=>writeFile(resolve(out,'execution.json'),JSON.stringify(report,null,2)+'\n');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.wasm':'application/wasm','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'};
const server=createServer(async(req,res)=>{
 try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);report.localRequests.push({path:pathname,method:req.method});
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return}
  const file=resolve(snapshot,pathname.slice(1)||'index.html');if(!file.startsWith(snapshot+'/')){res.writeHead(404);res.end();return}
  const info=await stat(file);if(!info.isFile()){res.writeHead(404);res.end();return}
  res.writeHead(200,{'content-type':types[extname(file)]??'application/octet-stream','content-length':info.size,'cache-control':'no-store'});
  if(req.method==='HEAD')res.end();else createReadStream(file).pipe(res);
 }catch{if(!res.headersSent)res.writeHead(404);res.end()}
});
let browser,context,page;const saveError=error=>({name:error?.name??'Error',message:error?.message??String(error)});
try{
 await new Promise((done,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',done)});const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--enable-unsafe-webgpu','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 report.browserVersion=browser.version();context=await browser.newContext({viewport:{width:1440,height:1100},acceptDownloads:true,serviceWorkers:'block'});
 context.on('request',request=>{const u=new URL(request.url());report.network.push({origin:u.origin,path:u.pathname,method:request.method()})});
 await context.route('**/*',async route=>{
  const request=route.request(),u=new URL(request.url());if(u.origin===origin)return route.continue();
  const resource=u.origin==='https://huggingface.co'&&u.pathname.startsWith(modelPrefix)?u.pathname.slice(modelPrefix.length):undefined;
  const intentional=resource===target;report.blockedRequests.push({origin:u.origin,path:u.pathname,method:request.method(),resource,intentional});await route.abort('failed');
 });
 await context.exposeFunction('recordProbeWorker',event=>report.workerEvents.push({...event,at:new Date().toISOString()}));
 await context.addInitScript(()=>{
  const NativeWorker=window.Worker;
  window.Worker=class extends NativeWorker{
   constructor(...args){super(...args);const url=String(args[0]);window.recordProbeWorker({type:'created',url});this.addEventListener('message',event=>window.recordProbeWorker({type:'message',message:event.data}));this.addEventListener('error',event=>window.recordProbeWorker({type:'error',message:event.message}));}
   postMessage(message,...rest){if(message?.type==='run')window.recordProbeWorker({type:'run',caseId:message.request.caseId,imageSha256:message.request.expectedSha256,mode:message.request.mode});return super.postMessage(message,...rest)}
  };
 });
 page=await context.newPage();page.setDefaultTimeout(30_000);page.on('pageerror',error=>report.pageErrors.push(saveError(error)));page.on('console',message=>{if(message.type()==='error')report.consoleErrors.push(message.text())});
 await page.goto(origin+'/core-ai-benchmark.html',{waitUntil:'networkidle'});await page.locator('#benchmark-case option[value="case-01"]').waitFor({state:'attached'});
 assert.equal(await page.locator('.bench-version').innerText(),'0.26.1');assert.equal(report.workerEvents.length,0);assert.equal(report.blockedRequests.length,0);
 assert.equal(report.localRequests.filter(x=>x.path.includes('/images/')).length,0);report.checks.push('No eager worker/model/image requests before explicit consent/run.');
 await page.locator('#benchmark-mode').selectOption('compatibility');await page.locator('#benchmark-count').selectOption('1');await page.locator('#benchmark-case').selectOption('case-01');await page.locator('#benchmark-device').fill('Chromium SwiftShader intentional network-failure test; not iPhone');await page.locator('#benchmark-consent').check();
 assert(await page.locator('#benchmark-run').isEnabled(),await page.locator('#benchmark-support').innerText());
 await page.locator('#benchmark-run').click();await page.waitForFunction(()=>document.querySelector('#benchmark-stop')?.disabled===true);
 report.statusText=await page.locator('#benchmark-status').innerText();await page.screenshot({path:resolve(out,'failure-ui.png'),fullPage:true});
 async function exportJson(name){const pending=page.waitForEvent('download');await page.locator('#benchmark-export').click();const download=await pending,bytes=await readFile(await download.path());await writeFile(resolve(out,name),bytes);return JSON.parse(bytes)}
 const exported=await exportJson('device-report.json');report.deviceReport=exported;
 assert.equal(exported.appVersion,'0.26.1');assert.equal(exported.runs.length,1);const run=exported.runs[0],entry=run.cases[0];
 assert.equal(run.appVersion,'0.26.1');assert.equal(run.mode,'compatibility');assert.equal(run.maxNewTokens,32);assert.equal(run.status,'failed');assert.equal(run.preflightAdapter.softwareAdapter,true);
 assert.deepEqual(run.selectedCaseIds,['case-01']);assert.equal(run.unselectedCaseIds.length,39);assert.equal(entry.status,'failed');assert.equal(entry.imageSha256,sample.sha256);assert.equal(entry.result,undefined);
 assert.equal(entry.errorDiagnostic.stage,'processor-load');assert.equal(entry.errorDiagnostic.operation,'fetch');assert.equal(entry.errorDiagnostic.resource,target);assert.equal(entry.errorDiagnostic.name,'TypeError');assert.match(entry.errorDiagnostic.message,/fetch|load/i);
 assert.equal(entry.errorDiagnostic.loadedBytes,undefined);assert.equal(entry.errorDiagnostic.totalBytes,undefined);assert.equal(entry.errorDiagnostic.httpStatus,undefined);
 assert.equal(entry.lastProgress.progress.stage,'processor-load');assert(entry.lastProgress.caseElapsedMs>=0);assert(entry.elapsedMs>=entry.lastProgress.caseElapsedMs);
 assert.match(await page.locator('.bench-case-diagnostic').innerText(),/preprocessor_config\.json/);assert.equal(exported.protocol.qualityScores,null);assert.equal(exported.memory.gpuMemoryBytes,null);
 assert.equal(report.blockedRequests.length,1);assert.equal(report.blockedRequests[0].intentional,true);assert.equal(report.blockedRequests[0].resource,target);
 assert.equal(report.workerEvents.filter(e=>e.type==='created').length,1);assert.equal(report.workerEvents.filter(e=>e.type==='run').length,1);assert(!report.workerEvents.some(e=>e.message?.type==='result'||e.message?.progress?.stage==='generate'));
 assert(!report.network.some(e=>/\.onnx(?:_data)?$/.test(e.path)));assert.equal(report.pageErrors.length,0);
 report.checks.push('Real worker emitted a structured processor-load/fetch/preprocessor_config.json failure preserving the original TypeError.','Unknown transfer bytes and HTTP status remained absent.','Verified case-01 input; one worker/run only, no weights or inference.');
 const before={workers:report.workerEvents.filter(e=>e.type==='created').length,requests:report.blockedRequests.length,images:report.localRequests.filter(e=>e.path.includes('/images/')).length};
 await page.reload({waitUntil:'networkidle'});await page.locator('#benchmark-case option[value="case-01"]').waitFor({state:'attached'});assert.match(await page.locator('#benchmark-status').innerText(),/Recovered/);
 const recovered=await exportJson('recovered-device-report.json');assert.deepEqual(recovered.runs,exported.runs);assert.equal(await page.locator('#benchmark-consent').isChecked(),false);
 assert.deepEqual({workers:report.workerEvents.filter(e=>e.type==='created').length,requests:report.blockedRequests.length,images:report.localRequests.filter(e=>e.path.includes('/images/')).length},before);
 await page.screenshot({path:resolve(out,'recovered-ui.png'),fullPage:true});report.checks.push('Reload restored identical failure/progress metadata without consent, image fetch, worker or automatic retry.');
 report.status='passed';
}catch(error){report.status='failed';report.harnessError=saveError(error);if(page&&!page.isClosed())await page.screenshot({path:resolve(out,'harness-failure.png'),fullPage:true}).catch(()=>{});process.exitCode=1}
finally{
 for(const path of [...new Set(report.localRequests.map(x=>x.path).filter(p=>/\.(?:html|js|mjs|css|wasm)$/.test(p)))]){try{const bytes=await readFile(resolve(snapshot,path.slice(1)));report.assets.push({path,bytes:bytes.length,sha256:sha(bytes)})}catch{}}
 await context?.close();await browser?.close();if(server.listening)await new Promise(done=>server.close(done));report.completedAt=new Date().toISOString();await record();console.log(JSON.stringify({status:report.status,checks:report.checks,error:report.harnessError,artifact:out}));
}
