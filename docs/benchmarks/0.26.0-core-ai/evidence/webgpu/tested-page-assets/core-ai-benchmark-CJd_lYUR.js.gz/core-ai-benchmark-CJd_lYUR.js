(function(){const n=document.createElement("link").relList;if(n&&n.supports&&n.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))r(s);new MutationObserver(s=>{for(const i of s)if(i.type==="childList")for(const a of i.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&r(a)}).observe(document,{childList:!0,subtree:!0});function t(s){const i={};return s.integrity&&(i.integrity=s.integrity),s.referrerPolicy&&(i.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?i.credentials="include":s.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(s){if(s.ep)return;s.ep=!0;const i=t(s);fetch(s.href,i)}})();const ye="0.26.0",ee={version:ye},ve=2;function Ce(e){return"Describe only visible features of this image crop. Give up to three short bullet points about colour, texture and visible edges or gaps. If it does not clearly show rock or is unclear, say so. Do not infer rock type, minerals, strength, soundness, fracture cause, RQD, or numerical properties."}const ne={id:"qwen3.5-0.8b-opt",label:"Qwen3.5 0.8B",repo:"onnx-community/Qwen3.5-0.8B-ONNX-OPT",revision:"9a4c21d8f724176b0a7edaaed36303044451886e",downloadMiB:1001,weightBytes:1049662346,dtype:{embed_tokens:"q4",vision_encoder:"fp32",decoder_model_merged:"q4"}},_e="geomodel3d-qwen-benchmark",ae=Ce(),se=ve,Te="4.3.2",Le="1.31.1",W=30*6e4;function j(e){if(e==="quality")return 128;if(e==="compatibility")return 32;throw new Error("Choose a quality or compatibility benchmark.")}function te(e){if(!e||typeof e!="object"||!/^case-(?:0[1-9]|[1-3][0-9]|40)$/.test(e.caseId))throw new Error("Choose a case from the fixed forty-image benchmark.");if(j(e.mode),typeof e.expectedSha256!="string"||!/^[a-f0-9]{64}$/.test(e.expectedSha256))throw new Error("The benchmark image needs its frozen SHA-256 hash.");const n="data:image/png;base64,";if(typeof e.image!="string"||!e.image.startsWith(n)||e.image.length>28e5)throw new Error("Benchmark input must be a local 512 × 512 PNG.");const t=e.image.slice(n.length);if(!t.length||t.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/.test(t))throw new Error("Invalid benchmark PNG encoding.");const r=Uint8Array.from(atob(t),i=>i.charCodeAt(0));if(r.length<33||[137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82].some((i,a)=>r[a]!==i))throw new Error("Invalid benchmark PNG header.");const s=new DataView(r.buffer);if(s.getUint32(16)!==512||s.getUint32(20)!==512)throw new Error("Benchmark input must be exactly 512 × 512 pixels.");return r}async function Ae(e){const n=te(e);if(!globalThis.crypto?.subtle)throw new Error("Secure image hashing is unavailable. Open the benchmark over HTTPS or localhost.");const t=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",n))).map(r=>r.toString(16).padStart(2,"0")).join("");if(t!==e.expectedSha256)throw new Error("The benchmark image does not match its frozen SHA-256 hash. No model was downloaded.");return{bytes:n,sha256:t}}function re(e){const n=e,t=l=>typeof n?.info?.[l]=="string"?String(n.info[l]).slice(0,256):"",r=t("vendor"),s=t("architecture"),i=t("device"),a=t("description"),o=[r,s,i,a].join(" ").toLowerCase(),h=/swiftshader|llvmpipe|software|lavapipe|microsoft basic render/.test(o)?!0:/apple|nvidia|intel|\bamd\b|qualcomm|adreno|mali/.test(o)?!1:null,f=l=>typeof n?.limits?.[l]=="number"&&Number.isFinite(n.limits[l])&&Number(n.limits[l])>=0?Number(n.limits[l]):null;return{vendor:r,architecture:s,device:i,description:a,features:n?.features?Array.from(n.features).filter(l=>typeof l=="string").slice(0,128).sort():[],softwareAdapter:h,limits:{maxBufferSize:f("maxBufferSize"),maxStorageBufferBindingSize:f("maxStorageBufferBindingSize")}}}function Se(e=performance){const n=e?.memory?.usedJSHeapSize;return{gpuMemoryBytes:null,jsHeapUsedBytes:typeof n=="number"&&Number.isFinite(n)&&n>=0?n:null,scope:"Total GPU memory is unavailable through WebGPU. Optional worker JS heap bytes exclude GPU allocations and are not total model memory."}}function ie(e,n){const t=j(n.mode),r=ne;if(!e||e.caseId!==n.caseId||e.mode!==n.mode||e.modelId!==r.id||e.model!==r.repo||e.revision!==r.revision||e.imageSha256!==n.expectedSha256||e.imageWidth!==512||e.imageHeight!==512||e.device!=="webgpu"||e.runtimeVersion!==Te||e.onnxRuntimeVersion!==Le||e.prompt!==ae||e.promptVersion!==se||e.enableThinking!==!1||e.maxNewTokens!==t||e.generation?.maxNewTokens!==t||e.generation?.doSample!==!1||e.generation?.repetitionPenalty!==1.1||Object.entries(r.dtype).some(([s,i])=>e.dtypes?.[s]!==i))throw new Error("Benchmark response does not match the selected image, model or protocol.");if(typeof e.text!="string"||!e.text.trim()||e.text.length>16384||!Number.isSafeInteger(e.generatedTokens)||e.generatedTokens<1||e.generatedTokens>t||!Number.isSafeInteger(e.inputTokens)||e.inputTokens<1||e.outputLimitReached!==e.generatedTokens>=t)throw new Error("Benchmark returned an invalid or empty output.");for(const s of["loadMs","preprocessingMs","inferenceMs","totalMs","tokensPerSecond","downloadBytes"])if(!Number.isFinite(e[s])||e[s]<0)throw new Error("Benchmark returned invalid timing metadata.");if(e.firstTokenMs!==null&&(!Number.isFinite(e.firstTokenMs)||e.firstTokenMs<0||e.firstTokenMs>e.inferenceMs+1))throw new Error("Benchmark returned invalid first-token timing.");if(typeof e.modelReused!="boolean"||!["available","unavailable"].includes(e.cacheState)||e.cached!==void 0&&typeof e.cached!="boolean")throw new Error("Benchmark returned invalid cache metadata.");if(!e.adapter||!Array.isArray(e.adapter.features)||e.adapter.features.length>128||e.adapter.features.some(s=>typeof s!="string")||![!0,!1,null].includes(e.adapter.softwareAdapter)||!e.adapter.limits||!e.memory||e.memory.gpuMemoryBytes!==null)throw new Error("Benchmark returned invalid device metadata.");for(const s of["vendor","architecture","device","description"])if(typeof e.adapter[s]!="string"||e.adapter[s].length>256)throw new Error("Benchmark returned invalid adapter metadata.");for(const s of[e.adapter.limits.maxBufferSize,e.adapter.limits.maxStorageBufferBindingSize,e.memory.jsHeapUsedBytes])if(s!==null&&(!Number.isFinite(s)||s<0))throw new Error("Benchmark returned invalid memory metadata.");if(!Array.isArray(e.imageGrid)||e.imageGrid.length!==1||e.imageGrid[0].length!==3||e.imageGrid[0].some(s=>!Number.isSafeInteger(s)||s<1))throw new Error("Benchmark returned invalid image-grid metadata.");return{caseId:e.caseId,mode:e.mode,modelId:e.modelId,model:e.model,revision:e.revision,dtypes:{...r.dtype},prompt:e.prompt,promptVersion:e.promptVersion,enableThinking:!1,generation:{doSample:!1,repetitionPenalty:1.1,maxNewTokens:t},text:e.text,generatedTokens:e.generatedTokens,inputTokens:e.inputTokens,maxNewTokens:t,outputLimitReached:e.outputLimitReached,imageSha256:e.imageSha256,imageWidth:512,imageHeight:512,imageGrid:e.imageGrid.map(s=>[...s]),loadMs:e.loadMs,preprocessingMs:e.preprocessingMs,inferenceMs:e.inferenceMs,totalMs:e.totalMs,firstTokenMs:e.firstTokenMs,tokensPerSecond:e.tokensPerSecond,modelReused:e.modelReused,cacheState:e.cacheState,...e.cached===void 0?{}:{cached:e.cached},downloadBytes:e.downloadBytes,device:"webgpu",runtimeVersion:e.runtimeVersion,onnxRuntimeVersion:e.onnxRuntimeVersion,adapter:{vendor:e.adapter.vendor,architecture:e.adapter.architecture,device:e.adapter.device,description:e.adapter.description,features:[...e.adapter.features],softwareAdapter:e.adapter.softwareAdapter,limits:{maxBufferSize:e.adapter.limits.maxBufferSize,maxStorageBufferBindingSize:e.adapter.limits.maxStorageBufferBindingSize}},memory:{gpuMemoryBytes:null,jsHeapUsedBytes:e.memory.jsHeapUsedBytes,scope:Se().scope}}}async function oe(){if(typeof location<"u"&&location.protocol==="file:"||typeof document<"u"&&document.querySelector('meta[name="geomodel3d-standalone"]'))return{supported:!1,reason:"The device benchmark requires its hosted HTTPS page. Manual core-photo logging remains available offline."};if(typeof isSecureContext<"u"&&!isSecureContext)return{supported:!1,reason:"Open the device benchmark over HTTPS or localhost."};if(!globalThis.crypto?.subtle)return{supported:!1,reason:"Secure image hashing is unavailable in this browser."};const e=typeof navigator<"u"?navigator:void 0;if(!e?.gpu)return{supported:!1,reason:"WebGPU is unavailable in this browser. No model was downloaded."};try{const n=await e.gpu.requestAdapter();return n?{supported:!0,adapter:re(n)}:{supported:!1,reason:"No WebGPU adapter is available on this device. No model was downloaded."}}catch{return{supported:!1,reason:"This browser could not initialize WebGPU. No model was downloaded."}}}async function xe(){if(typeof caches>"u")throw new Error("Browser model-cache storage is unavailable.");return caches.delete(_e)}class De{constructor(n={}){if(this.options=n,n.timeoutMs!==void 0&&(!Number.isFinite(n.timeoutMs)||n.timeoutMs<1||n.timeoutMs>W))throw new Error("Benchmark timeout must be positive and no more than thirty minutes per case.")}options;worker;pending;sequence=0;disposed=!1;run(n,t){if(this.disposed)return Promise.reject(new Error("This benchmark client has been disposed."));if(this.pending)return Promise.reject(new Error("A benchmark case is already running."));let r;try{te(n),r={caseId:n.caseId,image:n.image,expectedSha256:n.expectedSha256,mode:n.mode}}catch(i){return Promise.reject(i)}const s=++this.sequence;return new Promise((i,a)=>{const o=setTimeout(()=>this.fail(new Error("This benchmark case timed out after its device budget. The model has been unloaded; the failed case must remain in the report.")),this.options.timeoutMs??W);this.pending={id:s,request:r,resolve:i,reject:a,progress:t,timer:o},this.start(s,r)})}async start(n,t){try{if(this.pending?.progress?.({phase:"checking",message:"Verifying the frozen image and this device's WebGPU support…"}),await Ae(t),this.pending?.id!==n)return;const r=await(this.options.supportCheck??oe)();if(this.pending?.id!==n)return;if(!r.supported)throw new Error(r.reason??"WebGPU is unavailable.");if(!this.worker){const s=(this.options.workerFactory??(()=>new Worker(new URL(""+new URL("coreBenchmark.worker-DwxwTrxh.js",import.meta.url).href,import.meta.url),{type:"module"})))();this.worker=s,s.onmessage=i=>{const a=i.data,o=this.pending;if(!(this.worker!==s||!o||!a||a.id!==o.id))if(a.type==="progress")a.progress&&["checking","loading","running"].includes(a.progress.phase)&&typeof a.progress.message=="string"&&o.progress?.(a.progress);else if(a.type==="result")try{const h=ie(a.result,o.request);clearTimeout(o.timer),this.pending=void 0,o.resolve(h)}catch(h){this.fail(h instanceof Error?h:new Error(String(h)))}else a.type==="error"&&this.fail(new Error(typeof a.message=="string"?a.message:"The benchmark worker failed."))},s.onerror=i=>{this.worker===s&&this.fail(new Error(i.message||"The benchmark worker failed. Its model has been unloaded."))},s.onmessageerror=()=>{this.worker===s&&this.fail(new Error("The benchmark worker returned an unreadable response."))}}this.worker.postMessage({type:"run",id:n,request:t})}catch(r){this.pending?.id===n&&this.fail(r instanceof Error?r:new Error(String(r)))}}fail(n){const t=this.pending;this.pending=void 0,this.worker?.terminate(),this.worker=void 0,t&&(clearTimeout(t.timer),t.reject(n))}stop(){this.fail(new DOMException("Benchmark cancelled and model unloaded.","AbortError"))}dispose(){this.stop(),this.disposed=!0}}const Pe=`protocol_id,case_id,image_path,image_sha256,review_state,reference_reviewer_id,reference_reviewer_role,reference_qualification_basis,reference_utc,source_labels_seen,model_outputs_seen_before_reference,visible_material,colour_observations,texture_markings_observations,boundary_gap_observations,uncertainties,reference_freeze_sha256,borehole_id,borehole_mapping_evidence_url,borehole_mapping_status,evaluation_reviewer_id,evaluation_utc,anonymous_output_id,colour_points,texture_points,boundary_points,uncertainty_points,supported_claims,contradicted_claims,unverified_claims,critical_failures,minimum_useful,fully_supported,review_reason,run_status,output_capped,reviewer_signoff\r
core-webgpu-pilot-2,case-01,public/core-benchmark-v026/images/case-01.png,9c4054282fd511b2583702a852c6df77bff4f69ddfa0c5276be162e1bd25a401,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-02,public/core-benchmark-v026/images/case-02.png,9ddde5be159f380665c3d57f6ad10e20dbe273b4a5360f603e670183ef0650b4,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-03,public/core-benchmark-v026/images/case-03.png,99a2303d1f71a179061588cdb6de4f227cf692b996a56097db175e15a4bc1695,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-04,public/core-benchmark-v026/images/case-04.png,ba11d926b0953bdaa645c2c81caee7f4d85189850290d15ee7391a658392d144,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-05,public/core-benchmark-v026/images/case-05.png,41071393c515df137a9211ce0be4bc18a28e302815d49438489ca54c741c9503,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-06,public/core-benchmark-v026/images/case-06.png,3aeb07923a3b47c4f5ed3fe4c66614dfe5af22963c4824be2c35d777d1e7d3c2,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-07,public/core-benchmark-v026/images/case-07.png,46826a752dd8014d80e29906bfe6cf0f1c35530b57fc8beb59ecb42242610f8f,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-08,public/core-benchmark-v026/images/case-08.png,b6579c30ef8d5b940fa1393fea5e7bbc839574bc37e06d3ffc6cb3574003da6b,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-09,public/core-benchmark-v026/images/case-09.png,9fef3d9d22ee55e7fde9b7b00d0d7fbbf07e141937fc9185723149339dd2ed5f,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-10,public/core-benchmark-v026/images/case-10.png,2004119b07871b7c8ec52cfb92e691191eca585383a776ea58e6861f158c8b26,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-11,public/core-benchmark-v026/images/case-11.png,e3ff0a50ea8fd669658f0747dc59fdbae1c829beb6dcd47a982a50c178a53098,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-12,public/core-benchmark-v026/images/case-12.png,54587569a6b18d1649ab8e1c63a2137ecd1500d049213898c74933d604ff574b,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-13,public/core-benchmark-v026/images/case-13.png,f3f5b3e39353a1fa5b9bf99c09bac68f084eff955a65eda95fe6954dc1c619ef,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-14,public/core-benchmark-v026/images/case-14.png,5795596b4ea9a5b3d159533836530a9b3a64456b292008a5729a5f138ff48d51,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-15,public/core-benchmark-v026/images/case-15.png,adc707643ab22ea07e19135786df2ef2ba1e5b2b25aa3c5a0398e1d24f1e49fc,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-16,public/core-benchmark-v026/images/case-16.png,78236ca70edc96e2eb782d52c9775ba7e5c02c714db8cd3f341ebee98a3b283c,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-17,public/core-benchmark-v026/images/case-17.png,89d0e0116ccb433ede9da830174d19beb749ccc4c46573fb1c7313fce05bf075,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-18,public/core-benchmark-v026/images/case-18.png,8152ab0b9647f4d30f122c1cbf902ae153f6048988efbee40e543188a7b12e43,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-19,public/core-benchmark-v026/images/case-19.png,3a49fe3fc2209fcc98bfae5bd64e895f23d2195ecc2f03b110f6fbfb59156e0b,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-20,public/core-benchmark-v026/images/case-20.png,20927579c8a6b56e2664dcdebee3ba7e62f279c8f811ca5f8acd448e57fd08c1,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-21,public/core-benchmark-v026/images/case-21.png,817fdc3eda3829d53d97384eab00242b654befa117d40260e9041bf52483a633,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-22,public/core-benchmark-v026/images/case-22.png,873683f1c11731e0005b21f135c935834f3e82449cdade6a68e4fef13a03223c,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-23,public/core-benchmark-v026/images/case-23.png,4c1fe540acc36b15205f10189727bdf279b192b0ffe1a6702387e766f904c5c3,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-24,public/core-benchmark-v026/images/case-24.png,7781293fd3ccfa68524aefffe440ad5f7d32b59c59935b37507344ba057164ea,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-25,public/core-benchmark-v026/images/case-25.png,738d31c2dffc7386da90b1e5e17a7cd47eeeaed05678faab03616aad69c70f7c,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-26,public/core-benchmark-v026/images/case-26.png,921683ccd0af84aa33f6d6d452d7f35f91a6b4557f515243c69dc4332884c56b,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-27,public/core-benchmark-v026/images/case-27.png,a10b4b6670b7232c2038314fee528f57c229a9471086532bc057b2da7f32bac6,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-28,public/core-benchmark-v026/images/case-28.png,bb5eed9271083a0b72a842061f753a8cc341def21ec8b1b25173de6f2a4a802a,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-29,public/core-benchmark-v026/images/case-29.png,a52cc13d67f458308b7dbaba9af034b65d4151935f3aca234e4305f1912d2064,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-30,public/core-benchmark-v026/images/case-30.png,8497cbdf0b10ffe5f00d82636af9ada1f1a474801fbf8968a94295dd1db997b4,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-31,public/core-benchmark-v026/images/case-31.png,e962c8bcffc157bdb7c40176686962876055539191555e781b89937e5221ed73,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-32,public/core-benchmark-v026/images/case-32.png,603f66d73c7de32874a05fdc1c97999d877033f90839b58a84b03faa0e55ec6d,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-33,public/core-benchmark-v026/images/case-33.png,6b585e57240b3db1f77ddaf9cbbd504e2a10c50acceb6d814862e6c0e1158413,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-34,public/core-benchmark-v026/images/case-34.png,7e8272a283a8be41287a67ea2f9e966a06c2f782cdcd316c2ee06279d76e9c63,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-35,public/core-benchmark-v026/images/case-35.png,24655cbe5dbb999fbfc6fcbddfd7877c955e10e1852fe3f0ecb796be56516b78,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-36,public/core-benchmark-v026/images/case-36.png,30debcd3c150851a238293e1c9849655f1224407c103beeaddef18e410bbea29,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-37,public/core-benchmark-v026/images/case-37.png,644493a10f1a0abff3437f38d15a933f27f6b0b4cd6e4b924bd3b80be52f03aa,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-38,public/core-benchmark-v026/images/case-38.png,5933713d3790f3e7b5aea3af0bf2687e82eef16d671b6cd2a0f335dc6e65cc4c,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-39,public/core-benchmark-v026/images/case-39.png,b887574931bb45510e07fb84ce87774489f489a1041c9dd20ca83e058d1b8570,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
core-webgpu-pilot-2,case-40,public/core-benchmark-v026/images/case-40.png,13d4405652055f28c750b22ab22b9c81b597b6d8bb1324e6ad99dc91eef55330,awaiting_reference,,,,,,,unassessed,,,,,,,,unverified,,,,,,,,,,,,unassessed,unassessed,,not_run,unassessed,\r
`,Ee=`{
  "schemaVersion": 1,
  "protocolId": "core-webgpu-pilot-2",
  "datasetId": "core-v026",
  "protocolFrozenAtUtc": "2026-11-15T08:04:04.287080Z",
  "protocolDesignFrozenBeforeNewInference": true,
  "status": "Prepared protocol; human quality, verified borehole independence and physical-device gates remain unassessed.",
  "scope": "Visible descriptions from local browser WebGPU. No lithology-classification, engineering-property or ground-model-accuracy validation.",
  "expectedCaseIds": [
    "case-01",
    "case-02",
    "case-03",
    "case-04",
    "case-05",
    "case-06",
    "case-07",
    "case-08",
    "case-09",
    "case-10",
    "case-11",
    "case-12",
    "case-13",
    "case-14",
    "case-15",
    "case-16",
    "case-17",
    "case-18",
    "case-19",
    "case-20",
    "case-21",
    "case-22",
    "case-23",
    "case-24",
    "case-25",
    "case-26",
    "case-27",
    "case-28",
    "case-29",
    "case-30",
    "case-31",
    "case-32",
    "case-33",
    "case-34",
    "case-35",
    "case-36",
    "case-37",
    "case-38",
    "case-39",
    "case-40"
  ],
  "selection": {
    "expectedCases": 40,
    "publishedClasses": {
      "garbage": 10,
      "limestone": 10,
      "sandstone": 10,
      "shale": 10
    },
    "source": "Alzubaidi lithology dataset V1 through the credited Kaggle mirror V1; see dataset-manifest.json and NOTICE.md",
    "caseOrder": "case-01..10 garbage; case-11..20 limestone; case-21..30 sandstone; case-31..40 shale",
    "disjointFrom": "The eight exact source files in docs/benchmarks/0.25.0-core-ai/dataset-manifest.json",
    "algorithmAndSeed": "Frozen in the expanded dataset manifest before viewing or inference; no output-driven case replacement.",
    "independence": "Filename prefixes and distinct parent-photo strings are heuristics only. Official case-level mapping to boreholes/sites is required for an independence claim.",
    "inputsMustBeFrozenBeforeRun": true,
    "recordHashes": [
      "source JPEG SHA256",
      "analyzed PNG SHA256",
      "public manifest SHA256",
      "full source manifest SHA256",
      "protocol SHA256",
      "rubric SHA256"
    ],
    "publicManifestSha256": "b61549c3de8714e2f015056276efc23dfb3c6f3e1206fbd6611b68af3712c391",
    "sourceManifestSha256": "301b53789551d3423730f56572762ab99cee8f59b1d1e7b3dfa30c6cf80141d2",
    "parentPhotoExclusion": "The eight earlier cases and all 40 expanded cases use distinct inferred parent trays; the old cases and their inferred parent trays were excluded by the dataset selector. Parent-tray strings remain unverified heuristics."
  },
  "promptVersion": 2,
  "prompt": "Describe only visible features of this image crop. Give up to three short bullet points about colour, texture and visible edges or gaps. If it does not clearly show rock or is unclear, say so. Do not infer rock type, minerals, strength, soundness, fracture cause, RQD, or numerical properties.",
  "model": {
    "id": "qwen3.5-0.8b-opt",
    "repo": "onnx-community/Qwen3.5-0.8B-ONNX-OPT",
    "revision": "9a4c21d8f724176b0a7edaaed36303044451886e",
    "architecture": "Qwen3_5ForConditionalGeneration",
    "dtype": {
      "embed_tokens": "q4",
      "vision_encoder": "fp32",
      "decoder_model_merged": "q4"
    },
    "weightBytes": 1049662346,
    "enableThinking": false,
    "runtime": {
      "transformers": "4.3.2",
      "onnxRuntimeWeb": "1.31.1",
      "device": "webgpu"
    },
    "revisionPolicy": "Pin both from_pretrained revision and remotePathTemplate; no unversioned main tokenizer metadata request."
  },
  "imageProcessing": {
    "width": 512,
    "height": 512,
    "format": "PNG",
    "geometry": "Aspect-preserving crop, enlargement where necessary, neutral-gray padding; exact prepared bytes hashed. Enlargement adds no observed detail.",
    "qwenMinPixels": 262144,
    "qwenMaxPixels": 262144,
    "doImageSplitting": false,
    "sentMetadata": "No published class, source filename, borehole identity, depth, geological label or test result is sent to the model."
  },
  "generation": {
    "doSample": false,
    "repetitionPenalty": 1.1,
    "modes": {
      "quality": {
        "maxNewTokens": 128,
        "eligibleForLaterHumanQualityReview": true
      },
      "compatibility": {
        "maxNewTokens": 32,
        "eligibleForLaterHumanQualityReview": false
      }
    },
    "runOrder": "Selected case IDs in ascending order, one generation per selected case. Preserve failures, caps and cancellations. Do not choose a better answer from repeated generations.",
    "qualityCappedOutputs": "Retain and score the text as generated, mark capped/incomplete, and retain cap counts separately."
  },
  "execution": {
    "perCaseTimeoutMs": 1800000,
    "explicitUserStart": true,
    "sequentialSingleModelSession": true,
    "stopPolicy": "Stop or loss of page visibility terminates the worker and current fetch; preserve completed results, a cancelled/interrupted current case and unstarted selected cases. No auto-resume.",
    "resourceScope": "The 30-minute ceiling is a protective engineering timeout, not a usable-phone latency target.",
    "localValidationPlan": {
      "backend": "Software WebGPU if no hardware adapter is available",
      "selectedCaseIds": [
        "case-11"
      ],
      "mode": "quality",
      "maxNewTokens": 128,
      "maximumAttempts": 1,
      "cohortCoverage": "One selected attempt out of 40; completion or timeout reported honestly. All other browser cases remain not run on this device.",
      "rationale": "First limestone case in the predeclared ordering; selected before viewing the case or its output. It cannot estimate cohort quality.",
      "exceptions": "An infrastructure fix may require a new named run. Preserve the original attempt and reason; never overwrite or select the best output."
    },
    "optionalCpuDiagnostics": "May run all 40 locally on CPU, but remain a separately labelled diagnostic dataset. CPU outputs/timings cannot fill missing browser cases or satisfy any browser-quality/device gate.",
    "realDevicePlan": "Run the full 40-case quality cohort on a physically operated target device; record self-reported device model and actual browser/adapter data separately. Emulated iPhone viewport or software WebGPU is not physical iPhone Safari.",
    "timingDefinitions": {
      "firstTokenMs": "Worker monotonic elapsed time from model.generate start to the first output token; excludes image fetch, hash verification, model loading and preprocessing.",
      "workerTotalMs": "Worker monotonic time including image verification/decode, model/session loading, preprocessing and generation; excludes page image fetch and client verification.",
      "caseElapsedMs": "Page monotonic elapsed time from starting a selected case through image fetch, hash verification, client checks, worker loading/preprocessing/generation, and receipt of its terminal result. This is the warm end-to-end p95 field. Interrupted and failed cases retain elapsed time but are not successful latency samples.",
      "clockTimestamps": "ISO timestamps identify events; elapsed values use monotonic performance.now and are not derived from wall-clock subtraction."
    }
  },
  "humanReview": {
    "state": "awaiting-qualified-human-review",
    "references": "A qualified human records image-only observations before seeing model text, then signs and freezes that reference file with SHA256. No assistant-written observations are credited as human review.",
    "timing": "If technical inference already occurred, keep outputs sealed from the reference reviewer. Record that references were frozen before output disclosure, not before inference. If the reviewer has seen outputs, record contamination and use a fresh blinded reviewer for independent references.",
    "sourceLabels": "Keep source classes and borehole filenames hidden while writing visual references where practical; record any disclosure honestly. Published geologist-derived class labels are not new human visual review.",
    "grading": "After reference freeze, provide anonymous output IDs without model names, backend, run timings or device labels. Record the limited blinding of a single-model study. Preserve the output-to-run mapping separately until grading is frozen.",
    "missingData": "Blank/unassessed values are missing evidence, never zero scores or passing cases. Failures and unstarted cases remain in the cohort denominator.",
    "materials": [
      "rubric.md",
      "human-review-template.csv",
      "human-review-guide.md"
    ]
  },
  "researchScreeningCriteria": {
    "status": "Predeclared research thresholds, not user-accepted performance requirements or validated accuracy standards.",
    "humanQuality": {
      "reviewedBrowserQualityCases": 40,
      "minimumUsefulCases": 32,
      "fullySupportedCases": 30,
      "maximumCriticalFailureOutputs": 0,
      "maximumSubstantiveVisualContradictionOutputs": 2,
      "minimumAppropriateNonCoreOrMixedControlAnswers": 8,
      "controlDenominator": 10,
      "controlInterpretation": "Assess the visible content; a garbage-class patch can include a rock edge and does not require a categorical no-rock answer.",
      "maximumCappedQualityOutputs": 4,
      "reviewers": "At least one qualified human completes and signs image-only references and blinded grading; independently re-review critical or disputed cases. Record reviewer role and qualification basis; do not invent credential verification."
    },
    "sourceIndependence": {
      "minimumAuthoritativelyMappedBoreholes": 5,
      "required": "Case-level linkage to authoritative borehole IDs and source parent images, evidence URLs, and declaration of overlap with development/tuning data. A matching name in a registry alone is insufficient.",
      "unknownMeans": "unassessed; do not claim the full gate passed or that cases were held out by borehole/site.",
      "pretrainingOverlap": "unknown; public data cannot establish absence from general-model pretraining."
    },
    "physicalDevice": {
      "requiredDevice": "Physical target phone/browser, such as user-operated iPhone 17 Safari; record actual versions and date.",
      "completeQualityCases": 40,
      "maximumExecutionErrorsOrUnplannedInterruptions": 0,
      "minimumWarmCompletedCasesForLatency": 30,
      "warmDefinition": "Same retained model session; modelReused=true. Cold/download/session-load time is reported separately.",
      "warmFirstTokenP95TargetMs": 10000,
      "warmEndToEndP95TargetMs": 30000,
      "percentileMethod": "Nearest-rank p95: ascending values at one-based rank ceil(0.95*n). Report n, all failures and unmeasured values; do not discard slow successful cases.",
      "memory": "Report supported JS-heap metrics only as JS heap. GPU/process peak memory is unknown unless measured with a named external method; never infer it from model weight bytes or successful completion. No numerical device-memory-budget claim can pass without a stated budget and valid measurement.",
      "softwareAdapter": "Compatibility evidence only; excluded from physical-device latency and memory suitability claims."
    },
    "decision": "All required evidence must be present before calling the full gate passed. Any failed criterion is failed; missing evidence is unassessed. This protocol cannot authorize automatic geological interpretation or a default-model change."
  },
  "reporting": {
    "required": [
      "expected cohort of 40",
      "selected case IDs and selection rule",
      "per-case not-run/running/completed/failed/cancelled/interrupted/timed-out state",
      "mode and token cap",
      "input/model/protocol hashes",
      "actual backend/adapter/runtime versions",
      "cold and warm timing distinction",
      "first-token timing definition and missing values",
      "capped and empty outputs",
      "self-reported device context separated from observed browser metadata",
      "human-review status and reference/output disclosure order",
      "source-independence status",
      "all attempts and stated exceptions"
    ],
    "noAutomaticAccuracyScore": true,
    "separateCoverageAndQuality": true,
    "noPoolingCpuAndWebGpu": true,
    "noPoolingCompatibilityAndQuality": true,
    "noImageBytesInExport": true,
    "noImageUpload": true
  },
  "limitations": [
    "Forty selected public patches remain exploratory and may be correlated.",
    "Published class labels describe source classes, not visual ground truth for RQD, soundness, fracture origin or engineering properties.",
    "Already cropped patches do not test whole-row versus individual-piece improvement.",
    "Greedy generation can differ across CPU/WebGPU/runtime implementations; parity must not be assumed.",
    "The application model selector and default remain unchanged while expert and physical-device evidence are missing."
  ]
}
`,Re=`# Expanded core-image pilot: human review rubric

Protocol: \`core-webgpu-pilot-2\`. This rubric is prepared before new inference. Forty frozen cases and fixed model settings are an evaluation design, not a completed evaluation. Qualified human visual references and grading are still required. [Protocol](protocol.json) · [Review guide](human-review-guide.md) · [Blank sheet](human-review-template.csv).

## Reference first

A qualified human inspects each exact PNG without model text, records visible colour, texture/markings, boundaries/gaps and uncertainties, then signs and freezes that reference file with its SHA256. Record reviewer identity, role, qualification basis, date, any source-label exposure and any prior exposure to outputs. Do not fill these fields on someone's behalf or turn assistant-authored notes into human review.

Technical model runs can precede human reference preparation if their text remains hidden from the reference reviewer. Record the actual order. This permits a reference frozen before **output disclosure**, but does not justify saying it preceded inference. A reviewer who already saw outputs cannot retrospectively supply an independent reference; keep that work labelled as output-informed and obtain a fresh blinded reference if independence is required.

Published lithology classes came from source geologist-derived logs. They are not new human observations of these crops. A folder named \`garbage\` can contain tray material plus a rock edge; assess the visible content rather than forcing every control to be entirely non-rock. Do not use source classes, inferred borehole prefixes or later model suggestions to fill missing visual evidence. Preserve source attribution under the dataset's separate licence.

## Eligible output and missing evidence

Only an actual **browser WebGPU quality-mode** run with the fixed 128-token cap, pinned model/prompt and verified input hash can enter this study's browser-quality gate. Compatibility mode (32 tokens), CPU diagnostics, mock outputs and other protocols remain separate. A capped quality answer is reviewed as produced and marked incomplete; it is not replaced with a preferred retry.

Preserve every planned case and status. A not-run, cancelled, failed or timed-out case has no invented score. A completed case without a human review remains **unassessed**. Missing values are not zero scores and never count as passing. The full-cohort denominator is 40; separately show attempted, completed, human-reviewed and useful counts. One successful case is one observed completion, not 40-case validation.

The organizer supplies image, frozen reference, prompt and anonymous output ID, removing model name, backend and timing from the grading packet. Preserve the ID-to-run mapping separately until scores are frozen. In this single-model study identity may still be inferred; report this limited masking honestly, never as a fully blind independent panel.

## Four descriptive categories

Score each category 0–2 with a reason tied to a reference observation. This retains the earlier pilot's point definitions; **points are not accuracy percentages**. The rubric gives one point for omission, so a nonresponsive answer may score 4/8 while failing usefulness. Always report usefulness and claim classifications alongside points. Record any newly noticed visual feature separately as a post-hoc observation; do not silently revise the frozen reference.

| Category | 2 points | 1 point | 0 points |
|---|---|---|---|
| Colour | Specific visible colour observations match the reference. | Generic, incomplete or omitted, without substantive contradiction. | A substantive colour claim contradicts the image. |
| Texture or markings | Specific visible texture/markings match what this resolution supports. | Generic, incomplete or omitted, without substantive contradiction. | Invented/contradicted texture or detail beyond the visible resolution. |
| Boundaries or gaps | Correctly describes visible edges/gaps, or explicitly recognizes no reliable boundary is discernible. | Omits an applicable clear feature or remains nonspecific without inventing one. | Invents boundaries, gaps, counts or arrangements, or confuses padding/labels with material. |
| Uncertainty | Matches actual ambiguity and acknowledges relevant image limits. Clear facts need no boilerplate disclaimer. | Generic uncertainty or incomplete treatment of a relevant limit, without a confident unsupported resolution. | Confidently resolves an ambiguous feature or treats unclear/non-core content as an established geological observation. |

All four categories apply unless the image-only reviewer records an exclusion and reason before seeing model text. Keep the applicable maximum explicit. Do not normalize differently applicable scores into an accuracy claim. Neither verbosity nor repeated caveats earns additional credit. Hedging does not rescue a contradicted feature.

## Classify every factual claim

Split output into atomic claims without changing its wording. Record each quoted claim, classification, evidence or uncertainty, and whether it is critical:

- **Supported visually:** directly inspectable in the exact crop or frozen reference.
- **Supported only by published context:** source records establish it, but the image-only task does not. Do not count this as visual support.
- **Contradicted visually:** conflicts with the image; explain why.
- **Not verifiable from the crop:** the required scale, context, resolution, measurement or causal evidence is absent.
- **Appropriate abstention:** correctly states a relevant limitation without asserting the absent property.

Count unverified claims separately, including in otherwise useful answers. Classify contextual wording manually; a keyword such as “strength” in “strength cannot be determined” is not a strength estimate. Image counts are distinct from numerical engineering properties, but counts still require visual support.

An affirmative unsupported inference about lithology, mineral identity, soundness, rock quality, natural-versus-mechanical fracture cause, RQD or engineering properties is a **critical failure**. A clearly non-rock control confidently called a rock specimen is also critical. A source class that happens to match an asserted lithology does not excuse the forbidden inference. “Possibly” does not turn an unobservable property into evidence. Record exact text and reasoning; high colour/texture points cannot offset a critical failure.

## Two different usefulness measures

**Minimum useful:** at least one specific supported visual observation, no substantive visual contradiction, and no critical failure. Correctly recognizing an ambiguous/non-core crop with a specific visual reason can qualify. A generic “yes” or “this is drill core” does not. This rule can admit noncritical unverified interpretations; it does **not** mean every claim is reliable.

**Fully supported description:** satisfies minimum usefulness, contains no affirmative factual claim that is only source-context-supported or not verifiable from the crop, and handles relevant ambiguity appropriately. Pure uncertainty statements are assessed as abstentions rather than invented facts. Keep this stricter result separate; never relabel the earlier pilot's minimum-useful count as fully supported.

Use \`true\`, \`false\` or \`unassessed\` for both fields. They are human judgments, not automatic classifier confidence. Report nonresponse, critical flags, contradiction counts, unverified claims and cap status separately.

## Research screening criteria and decision

The protocol predeclares research thresholds: 40 human-reviewed browser quality cases, at least 32 minimum-useful and 30 fully supported descriptions, zero critical failures, at most two answers with substantive visual contradictions, at least eight appropriate answers among ten non-core/mixed controls, and at most four capped answers. These are proposed screening rules, not user-accepted performance requirements or statistical evidence of general accuracy.

The full gate also requires at least five authoritatively mapped boreholes with case-level linkage, documented development-data overlap, a complete actual target-device run and the protocol's timing/stability evidence. Filename prefixes alone do not establish independence, and public images cannot establish absence from pretraining. Physical iPhone Safari must be physically operated; Chromium phone emulation and software WebGPU cannot satisfy that gate.

Use **passed**, **failed**, or **unassessed** per criterion. Missing references, unverified hole mapping, missing full browser coverage or unavailable device measurements prevent claiming the full gate passed. If a numeric GPU-memory limit is proposed, valid measurement and an explicit budget are required; JS heap and weight-file bytes cannot substitute for GPU memory. Preserve unknown memory as unknown.

Even passing this exploratory gate would support further optional prototype evaluation only. It would not validate automatic geological logging, engineering estimates, a new default model, or the benefit of piece crops over matched full-row photographs. Those claims require their own evidence and decisions.
`,Be=`{
  "schemaVersion": 1,
  "datasetId": "core-v026",
  "rawCacheRoot": ".cache/v026-core-benchmark",
  "selection": {
    "frozenAt": "2026-11-15T07:38:45.522250+00:00",
    "seed": "geomodel3d-core-v026-20261115",
    "algorithm": "Round-robin garbage, limestone, sandstone, shale for 10 rounds. Within each class scan ascending SHA256(UTF8(seed + NUL + archive path)), accepting first unused inferred-parent tray whose inferred hole prefix has fewer than 3 selected cases. Exclude prior-eight exact paths and their inferred parent trays.",
    "selectedBeforeViewingOrInference": true,
    "originalInventorySha256": "536d634f8f50912a1fa531e95720ab31d0b3f7f7b880b38c1596f72d3339b58e",
    "prefixCounts": {
      "LB04D005": 3,
      "AS10D04": 3,
      "08PD04c": 3,
      "07PD01": 3,
      "IHAD3": 2,
      "IHAD2": 3,
      "PLAYFORD 1": 3,
      "HODD2": 2,
      "HODD1": 3,
      "WC05D001": 3,
      "MURNAROO 1": 1,
      "CDP008": 2,
      "OBD 7": 1,
      "RL 1": 1,
      "WDDD2": 2,
      "COD013": 1,
      "SH 7": 2,
      "PRICES BORE 1": 1,
      "COD012": 1
    }
  },
  "source": {
    "original": "https://data.mendeley.com/datasets/b6rj29mrss/1",
    "doi": "10.17632/b6rj29mrss.1",
    "originalLicense": "CC BY 4.0",
    "mirror": "https://www.kaggle.com/datasets/breejeshdhar/automated-lithology-classification",
    "mirrorVersion": 1,
    "mirrorLicense": "CC BY-SA 4.0",
    "download": "https://www.kaggle.com/api/v1/datasets/download/breejeshdhar/automated-lithology-classification?datasetVersionNumber=1",
    "archiveBytes": 1201499645,
    "mirrorBundleId": "3709250/6428854",
    "citation": "Alzubaidi, Fatimah (2021), Lithology dataset, Mendeley Data, V1, doi:10.17632/b6rj29mrss.1.",
    "paper": "https://doi.org/10.1016/j.petrol.2020.107933",
    "originalLicenseUrl": "https://creativecommons.org/licenses/by/4.0/",
    "mirrorLicenseUrl": "https://creativecommons.org/licenses/by-sa/4.0/",
    "labelMethodUrl": "https://www.sciencedirect.com/science/article/pii/S0920410520309888#sec2",
    "labelMethod": "Paper section 2.2 reports labels based on trained geologists\\u2019 lithology logs and manual checking of the final crops. These published classes are not a new GeoModel3D geologist review.",
    "originalArchiveSha256": "6db325de3c829dd2c0ada6a1528d94479e845f8c82e2703a6f65479a44e2f912",
    "originalArchiveDownloaded": false,
    "mirrorComparedWithOriginalArchive": false,
    "mirrorCredit": "Breejesh Dhar, Automated Lithology Classification, Kaggle, version 1 (2023).",
    "sourcePhotographsCredit": "Geological Survey of South Australia; see Alzubaidi dataset and paper.",
    "rawBytesChanges": "None. Copied unchanged from the public mirror archive.",
    "derivedImageChanges": "Benchmark PNG inputs are derived for this pilot; see benchmark protocol for exact transformations and per-input hashes."
  },
  "samples": [
    {
      "id": "case-01",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/LB04D005_21_row_4_14.jpg (2)_C2_.jpeg",
      "selectionRankWithinClass": 1,
      "holeLikeToken": "LB04D005",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "LB04D005_21",
      "parentLikeTokenVerified": false,
      "selectionOrder": 1,
      "path": "images/case-01.jpeg",
      "bytes": 10414,
      "sha256": "0bd4af351c993486fce494763d91fef1afee9f2db8ba0a73372fcb28447fe9c7",
      "width": 300,
      "height": 300,
      "zipCrc32": "c88e247a",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-02",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/07PD01_61_row_3_5.jpg_C3_.jpeg",
      "selectionRankWithinClass": 2,
      "holeLikeToken": "07PD01",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "07PD01_61",
      "parentLikeTokenVerified": false,
      "selectionOrder": 5,
      "path": "images/case-02.jpeg",
      "bytes": 9476,
      "sha256": "4111240058738b726ab91f75bdf0724dc42f582b16a524333d6d9208d962302f",
      "width": 300,
      "height": 300,
      "zipCrc32": "8a56e297",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-03",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/IHAD2_43_row_2_0.jpg (2)_C1_.jpeg",
      "selectionRankWithinClass": 3,
      "holeLikeToken": "IHAD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "IHAD2_43",
      "parentLikeTokenVerified": false,
      "selectionOrder": 9,
      "path": "images/case-03.jpeg",
      "bytes": 8632,
      "sha256": "1a71a9bf01f726aabaa4058fb0190e79c3fdd14f07cd823a2ae884a16bafd821",
      "width": 300,
      "height": 300,
      "zipCrc32": "17a5b51f",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-04",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/AS10D04_55_row_3_33.jpg_C3_.jpeg",
      "selectionRankWithinClass": 4,
      "holeLikeToken": "AS10D04",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "AS10D04_55",
      "parentLikeTokenVerified": false,
      "selectionOrder": 13,
      "path": "images/case-04.jpeg",
      "bytes": 10534,
      "sha256": "19e69e3c57223956e606149de5a95253c9917f9a7560f59b6f0dd6a3068c11b8",
      "width": 300,
      "height": 300,
      "zipCrc32": "18f6c926",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-05",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/LB04D005_16_row_2_11.jpg_C2_.jpeg",
      "selectionRankWithinClass": 5,
      "holeLikeToken": "LB04D005",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "LB04D005_16",
      "parentLikeTokenVerified": false,
      "selectionOrder": 17,
      "path": "images/case-05.jpeg",
      "bytes": 11673,
      "sha256": "833978af7c1b6606377eb0106e995611e101be7d4b6b5eb349c9cc73815d7a15",
      "width": 300,
      "height": 300,
      "zipCrc32": "3fddd299",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-06",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/OBD 7_21_row_4_13.jpg_C1_.jpeg",
      "selectionRankWithinClass": 6,
      "holeLikeToken": "OBD 7",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "OBD 7_21",
      "parentLikeTokenVerified": false,
      "selectionOrder": 21,
      "path": "images/case-06.jpeg",
      "bytes": 12494,
      "sha256": "317269ea793119fc20a4ac0d480f0f88b85ca038c1377830fa1a39f8ee399583",
      "width": 300,
      "height": 300,
      "zipCrc32": "373536dc",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-07",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/IHAD2_36_row_3_0.jpg_C3_.jpeg",
      "selectionRankWithinClass": 7,
      "holeLikeToken": "IHAD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "IHAD2_36",
      "parentLikeTokenVerified": false,
      "selectionOrder": 25,
      "path": "images/case-07.jpeg",
      "bytes": 7335,
      "sha256": "3389ede8f1505950d390d835202155acd24406964b5ce1d730035180d1880a32",
      "width": 300,
      "height": 300,
      "zipCrc32": "b575a7ec",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-08",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/08PD04c_89_row_1_0.jpg (2)_C3_.jpeg",
      "selectionRankWithinClass": 10,
      "holeLikeToken": "08PD04c",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "08PD04c_89",
      "parentLikeTokenVerified": false,
      "selectionOrder": 29,
      "path": "images/case-08.jpeg",
      "bytes": 9602,
      "sha256": "937aa4ee066df5b2bde578f72bb015a373f4dfe14d43562dd7a5ef4f1430e070",
      "width": 300,
      "height": 300,
      "zipCrc32": "27b58f28",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-09",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/PLAYFORD 1_18_row_1_15.jpg (2)_C3_.jpeg",
      "selectionRankWithinClass": 12,
      "holeLikeToken": "PLAYFORD 1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "PLAYFORD 1_18",
      "parentLikeTokenVerified": false,
      "selectionOrder": 33,
      "path": "images/case-09.jpeg",
      "bytes": 12033,
      "sha256": "a2bda0244e875d9e40d2fe85957747ef52a66317c5138cdefb1b7b4271fd47b8",
      "width": 300,
      "height": 300,
      "zipCrc32": "8d1bbf09",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-10",
      "referenceClass": "garbage",
      "originalArchivePath": "Lithology Dataset/test/garbage/PRICES BORE 1_8_row_2_0.jpg_C0_.jpeg",
      "selectionRankWithinClass": 13,
      "holeLikeToken": "PRICES BORE 1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "PRICES BORE 1_8",
      "parentLikeTokenVerified": false,
      "selectionOrder": 37,
      "path": "images/case-10.jpeg",
      "bytes": 11450,
      "sha256": "58aaad05ce66dae5a3a7869eeb00b68c3f816ac13ebc767441d80a7c8e4ae4cf",
      "width": 300,
      "height": 300,
      "zipCrc32": "a5413423",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-11",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/LB04D005_13_row_1_2_30.jpg.jpeg",
      "selectionRankWithinClass": 1,
      "holeLikeToken": "LB04D005",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "LB04D005_13",
      "parentLikeTokenVerified": false,
      "selectionOrder": 2,
      "path": "images/case-11.jpeg",
      "bytes": 13166,
      "sha256": "692d055a4dfac70d826441d4ebb7b94f6c6f1f3e4c916bd60cbd50bd14ddcdfc",
      "width": 300,
      "height": 300,
      "zipCrc32": "9f196688",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-12",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/08PD04c_37_row_2_1_19.jpg.jpeg",
      "selectionRankWithinClass": 2,
      "holeLikeToken": "08PD04c",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "08PD04c_37",
      "parentLikeTokenVerified": false,
      "selectionOrder": 6,
      "path": "images/case-12.jpeg",
      "bytes": 11353,
      "sha256": "be69de20ad6699ccd530711067e8a1e205c5c9aecf75fec90b6f2cdabb81cd51",
      "width": 280,
      "height": 280,
      "zipCrc32": "4378e381",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-13",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/PLAYFORD 1_1_row_1_26.jpeg",
      "selectionRankWithinClass": 3,
      "holeLikeToken": "PLAYFORD 1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "PLAYFORD 1_1",
      "parentLikeTokenVerified": false,
      "selectionOrder": 10,
      "path": "images/case-13.jpeg",
      "bytes": 8095,
      "sha256": "7e92b7329b0230234255e7236d8a96febf66744dceec10c69b9fd3e07f5e3e95",
      "width": 300,
      "height": 300,
      "zipCrc32": "c56a7827",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-14",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/WC05D001_24_row_4_2_13.jpg.jpeg",
      "selectionRankWithinClass": 4,
      "holeLikeToken": "WC05D001",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "WC05D001_24",
      "parentLikeTokenVerified": false,
      "selectionOrder": 14,
      "path": "images/case-14.jpeg",
      "bytes": 11539,
      "sha256": "96c260d6a3385f387febf009d4945373c7ce729a0da1a6a6211124432f5a420b",
      "width": 300,
      "height": 300,
      "zipCrc32": "d2be8dcb",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-15",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/WC05D001_9_row_4_1_7.jpg.jpeg",
      "selectionRankWithinClass": 5,
      "holeLikeToken": "WC05D001",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "WC05D001_9",
      "parentLikeTokenVerified": false,
      "selectionOrder": 18,
      "path": "images/case-15.jpeg",
      "bytes": 14513,
      "sha256": "013ab188ea05a6fdf51866e4eda9afa2ff5fa202b7fb784171ea37974d98a7c5",
      "width": 300,
      "height": 300,
      "zipCrc32": "b3e5bbb6",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-16",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/RL 1_5_row_2_33.jpeg",
      "selectionRankWithinClass": 7,
      "holeLikeToken": "RL 1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "RL 1_5",
      "parentLikeTokenVerified": false,
      "selectionOrder": 22,
      "path": "images/case-16.jpeg",
      "bytes": 10255,
      "sha256": "f1047e92ae11ab3bbeceeec9f4bb98a9fb836f9f3518e464027ed766e7d89b6f",
      "width": 300,
      "height": 300,
      "zipCrc32": "e6aa450f",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-17",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/WC05D001_32_row_1_1_20.jpg.jpeg",
      "selectionRankWithinClass": 17,
      "holeLikeToken": "WC05D001",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "WC05D001_32",
      "parentLikeTokenVerified": false,
      "selectionOrder": 26,
      "path": "images/case-17.jpeg",
      "bytes": 11852,
      "sha256": "8b3afa7e0d59fe99a36eefa9cc741bb8d1f518184f32ae01627cffb80916bb5c",
      "width": 300,
      "height": 300,
      "zipCrc32": "dd65eb8c",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-18",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/COD013_2_row_1_26.jpeg",
      "selectionRankWithinClass": 18,
      "holeLikeToken": "COD013",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "COD013_2",
      "parentLikeTokenVerified": false,
      "selectionOrder": 30,
      "path": "images/case-18.jpeg",
      "bytes": 12689,
      "sha256": "612dc0f8b8817eece185cfd442a97abe2a7d73b903b77b9c4d94e8c575e5009d",
      "width": 300,
      "height": 300,
      "zipCrc32": "8d146498",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-19",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/PLAYFORD 1_13_row_3_4.jpeg",
      "selectionRankWithinClass": 19,
      "holeLikeToken": "PLAYFORD 1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "PLAYFORD 1_13",
      "parentLikeTokenVerified": false,
      "selectionOrder": 34,
      "path": "images/case-19.jpeg",
      "bytes": 13269,
      "sha256": "0741375f72327d62396395ff2bb18537e8cb676498f22320a85b447143ebebd1",
      "width": 300,
      "height": 300,
      "zipCrc32": "ad61947e",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-20",
      "referenceClass": "limestone",
      "originalArchivePath": "Lithology Dataset/test/limestone/COD012_3_row_3_26.jpeg",
      "selectionRankWithinClass": 37,
      "holeLikeToken": "COD012",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "COD012_3",
      "parentLikeTokenVerified": false,
      "selectionOrder": 38,
      "path": "images/case-20.jpeg",
      "bytes": 9795,
      "sha256": "db07923bc561ecc2b6d8a9cb47dc5722fbb5af7760b1a028dbe33069f4d564e9",
      "width": 280,
      "height": 280,
      "zipCrc32": "dd36840c",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-21",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/AS10D04_68_row_0_11.jpeg",
      "selectionRankWithinClass": 1,
      "holeLikeToken": "AS10D04",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "AS10D04_68",
      "parentLikeTokenVerified": false,
      "selectionOrder": 3,
      "path": "images/case-21.jpeg",
      "bytes": 11888,
      "sha256": "393f6be3377018123119a394996a76e9709985b1c3420ba2028335fefb97e82d",
      "width": 300,
      "height": 300,
      "zipCrc32": "4650bb76",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-22",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/IHAD3_106_row_2_6.jpeg",
      "selectionRankWithinClass": 2,
      "holeLikeToken": "IHAD3",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "IHAD3_106",
      "parentLikeTokenVerified": false,
      "selectionOrder": 7,
      "path": "images/case-22.jpeg",
      "bytes": 12321,
      "sha256": "f9b7520fbee8de988feadeb2a2b1c33596066659e4c1c8aacca0695052cbded2",
      "width": 280,
      "height": 280,
      "zipCrc32": "9a6b28ac",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-23",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/HODD2_42_row_3_11.jpeg",
      "selectionRankWithinClass": 3,
      "holeLikeToken": "HODD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "HODD2_42",
      "parentLikeTokenVerified": false,
      "selectionOrder": 11,
      "path": "images/case-23.jpeg",
      "bytes": 10494,
      "sha256": "b7f4e244b8c244eb1758dbb58ece89cafee4f3a0b66ade4d0f3f1903fdc559d2",
      "width": 301,
      "height": 301,
      "zipCrc32": "a0b76726",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-24",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/MURNAROO 1_67_row_5_2.jpeg",
      "selectionRankWithinClass": 4,
      "holeLikeToken": "MURNAROO 1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "MURNAROO 1_67",
      "parentLikeTokenVerified": false,
      "selectionOrder": 15,
      "path": "images/case-24.jpeg",
      "bytes": 12073,
      "sha256": "e9ddad60f0e4bfd2c4f7bd3e00e2f384e8b5adf3c7193cdca81c5dc8f659513f",
      "width": 300,
      "height": 300,
      "zipCrc32": "1b1d2c9d",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-25",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/CDP008_41b_row_3_21.jpeg",
      "selectionRankWithinClass": 5,
      "holeLikeToken": "CDP008",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "CDP008_41b",
      "parentLikeTokenVerified": false,
      "selectionOrder": 19,
      "path": "images/case-25.jpeg",
      "bytes": 18410,
      "sha256": "941919ad48b00f62d8dcd9914d5cfecdddde637c062468dc54733c8c51f9d312",
      "width": 300,
      "height": 300,
      "zipCrc32": "5a7bb478",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-26",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/CDP008_44_row_3_11.jpeg",
      "selectionRankWithinClass": 6,
      "holeLikeToken": "CDP008",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "CDP008_44",
      "parentLikeTokenVerified": false,
      "selectionOrder": 23,
      "path": "images/case-26.jpeg",
      "bytes": 17249,
      "sha256": "7ea01e16fb7fa59d35246e23aa611358ce01c66d0eb8c44194c38d86f4ac2732",
      "width": 300,
      "height": 300,
      "zipCrc32": "e16624dd",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-27",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/HODD2_35_row_1_15.jpeg",
      "selectionRankWithinClass": 7,
      "holeLikeToken": "HODD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "HODD2_35",
      "parentLikeTokenVerified": false,
      "selectionOrder": 27,
      "path": "images/case-27.jpeg",
      "bytes": 14951,
      "sha256": "a80f977327da210bc53098e720ace60441cc38da3f0ac3d0257eef37034fdf8c",
      "width": 301,
      "height": 301,
      "zipCrc32": "266ba21f",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-28",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/IHAD3_186_row_2_10.jpeg",
      "selectionRankWithinClass": 8,
      "holeLikeToken": "IHAD3",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "IHAD3_186",
      "parentLikeTokenVerified": false,
      "selectionOrder": 31,
      "path": "images/case-28.jpeg",
      "bytes": 12773,
      "sha256": "95f3355363ea1bfdee7bbfa250902661c3d7429cd888419b5376a375ee6b7b3c",
      "width": 280,
      "height": 280,
      "zipCrc32": "8cb9efdd",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-29",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/SH 7_12_row_5_10.jpeg",
      "selectionRankWithinClass": 9,
      "holeLikeToken": "SH 7",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "SH 7_12",
      "parentLikeTokenVerified": false,
      "selectionOrder": 35,
      "path": "images/case-29.jpeg",
      "bytes": 13474,
      "sha256": "7d992e36108a6a6faefef855c2a9b8b54ae2340ee1c46f0da2372e20ab1adc26",
      "width": 300,
      "height": 300,
      "zipCrc32": "7f48dd30",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-30",
      "referenceClass": "sandstone",
      "originalArchivePath": "Lithology Dataset/test/sandstone/SH 7_9_row_1_15.jpeg",
      "selectionRankWithinClass": 10,
      "holeLikeToken": "SH 7",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "SH 7_9",
      "parentLikeTokenVerified": false,
      "selectionOrder": 39,
      "path": "images/case-30.jpeg",
      "bytes": 16858,
      "sha256": "366f0cdf4f491e682d4aa424d2abe9355cf60c4a5e05fd0ede349a4b708440b2",
      "width": 300,
      "height": 300,
      "zipCrc32": "20ac2eb3",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-31",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/08PD04c_80b_row_3_9.jpeg",
      "selectionRankWithinClass": 1,
      "holeLikeToken": "08PD04c",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "08PD04c_80b",
      "parentLikeTokenVerified": false,
      "selectionOrder": 4,
      "path": "images/case-31.jpeg",
      "bytes": 6763,
      "sha256": "19499d34cb919f700becdcc8a29159f3bb191a4aa97de13edaa29b87cad086a3",
      "width": 280,
      "height": 280,
      "zipCrc32": "e9ddde41",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-32",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/AS10D04_62_row_3_25.jpeg",
      "selectionRankWithinClass": 2,
      "holeLikeToken": "AS10D04",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "AS10D04_62",
      "parentLikeTokenVerified": false,
      "selectionOrder": 8,
      "path": "images/case-32.jpeg",
      "bytes": 7691,
      "sha256": "bc2edd8f1882fed72beaaa3b34fbd9c5d97a54f6d528c168eb53ca59080ea440",
      "width": 300,
      "height": 300,
      "zipCrc32": "9585f4df",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-33",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/HODD1_45b_row_4_40.jpeg",
      "selectionRankWithinClass": 3,
      "holeLikeToken": "HODD1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "HODD1_45b",
      "parentLikeTokenVerified": false,
      "selectionOrder": 12,
      "path": "images/case-33.jpeg",
      "bytes": 11135,
      "sha256": "7c2c44f003400ab6df830f75b3ab0a5479e888be854070361518d2bc1316e9ba",
      "width": 300,
      "height": 300,
      "zipCrc32": "11027a01",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-34",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/HODD1_37_row_3_30.jpeg",
      "selectionRankWithinClass": 6,
      "holeLikeToken": "HODD1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "HODD1_37",
      "parentLikeTokenVerified": false,
      "selectionOrder": 16,
      "path": "images/case-34.jpeg",
      "bytes": 7807,
      "sha256": "a910c161b379e2fb99d828b7eb1268f387998027f5e90141ad72c7ceb61f8d91",
      "width": 300,
      "height": 300,
      "zipCrc32": "b42da7c0",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-35",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/IHAD2_40_row_1_18.jpeg",
      "selectionRankWithinClass": 8,
      "holeLikeToken": "IHAD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "IHAD2_40",
      "parentLikeTokenVerified": false,
      "selectionOrder": 20,
      "path": "images/case-35.jpeg",
      "bytes": 9385,
      "sha256": "ff3ba318859655388f0d41c938379b59c2b2cca90caed76ffa7d2c06813a0603",
      "width": 300,
      "height": 300,
      "zipCrc32": "c9c69119",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-36",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/WDDD2_2b_row_3_38.jpeg",
      "selectionRankWithinClass": 11,
      "holeLikeToken": "WDDD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "WDDD2_2b",
      "parentLikeTokenVerified": false,
      "selectionOrder": 24,
      "path": "images/case-36.jpeg",
      "bytes": 12126,
      "sha256": "44eb609c4c63b45b5cb3902d3c770d2d900a286698b3082d90911e8801db8d60",
      "width": 300,
      "height": 300,
      "zipCrc32": "55b4c539",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-37",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/07PD01_66_row_0_25.jpeg",
      "selectionRankWithinClass": 15,
      "holeLikeToken": "07PD01",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "07PD01_66",
      "parentLikeTokenVerified": false,
      "selectionOrder": 28,
      "path": "images/case-37.jpeg",
      "bytes": 9518,
      "sha256": "cf6b614d409116de05b785730dcb891ec239a26c7cda1b4b50060802b0ee13c0",
      "width": 300,
      "height": 300,
      "zipCrc32": "5f5cf25d",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-38",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/WDDD2_7_row_4_18.jpeg",
      "selectionRankWithinClass": 17,
      "holeLikeToken": "WDDD2",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "WDDD2_7",
      "parentLikeTokenVerified": false,
      "selectionOrder": 32,
      "path": "images/case-38.jpeg",
      "bytes": 10776,
      "sha256": "37d98840a191cbb95442985e5eaac683c53b5c374fdb97997e85471da13fc9f2",
      "width": 300,
      "height": 300,
      "zipCrc32": "d9304762",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-39",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/07PD01_71_row_0_2.jpeg",
      "selectionRankWithinClass": 19,
      "holeLikeToken": "07PD01",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "07PD01_71",
      "parentLikeTokenVerified": false,
      "selectionOrder": 36,
      "path": "images/case-39.jpeg",
      "bytes": 8553,
      "sha256": "ae6577d11add1ef5a5aff859643f305950061bdc74c2f83936da96ad02a4ce9d",
      "width": 300,
      "height": 300,
      "zipCrc32": "b8030b21",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    },
    {
      "id": "case-40",
      "referenceClass": "shale",
      "originalArchivePath": "Lithology Dataset/test/shale/HODD1_51b_row_3_4.jpeg",
      "selectionRankWithinClass": 22,
      "holeLikeToken": "HODD1",
      "holeLikeTokenVerified": false,
      "parentLikeToken": "HODD1_51b",
      "parentLikeTokenVerified": false,
      "selectionOrder": 40,
      "path": "images/case-40.jpeg",
      "bytes": 11511,
      "sha256": "ebd3aeb38465bc18db3665e82dfb77cd2f680d67e5842b065855e2e3f6fac3b7",
      "width": 300,
      "height": 300,
      "zipCrc32": "21a46a0f",
      "license": "CC BY-SA 4.0",
      "changes": "None; exact JPEG bytes from pinned mirror archive."
    }
  ],
  "retrieval": {
    "rangePayloadBytes": 13168284,
    "rangeRequests": 124,
    "archiveBytes": 1201499645,
    "archiveFiles": 101995
  },
  "sampling": {
    "seed": "geomodel3d-core-v026-20261115",
    "algorithm": "Round-robin garbage, limestone, sandstone, shale for 10 rounds. Within each class scan ascending SHA256(UTF8(seed + NUL + archive path)), accepting first unused inferred-parent tray whose inferred hole prefix has fewer than 3 selected cases. Exclude prior-eight exact paths and their inferred parent trays.",
    "testClassCounts": {
      "garbage": 3000,
      "limestone": 3000,
      "sandstone": 3000,
      "shale": 3000
    },
    "selectedClassCounts": {
      "garbage": 10,
      "limestone": 10,
      "sandstone": 10,
      "shale": 10
    },
    "selectionBeforeViewing": true,
    "selectionBeforeInference": true,
    "split": "test",
    "priorPilotCasesExcluded": 8,
    "priorInferredParentTraysExcluded": 8,
    "distinctInferredPrefixes": 19,
    "maximumCasesPerInferredPrefix": 3,
    "distinctInferredParentTrays": 40,
    "siteOrBoreholeHoldoutVerified": false,
    "officialBoreholeIdentitiesVerified": 0,
    "caseIdOrder": "Ten garbage, ten limestone, ten sandstone, ten shale; original round-robin selection order retained per sample."
  },
  "identityVerification": {
    "status": "unverified",
    "reason": "No case-level authoritative mapping from source filenames to official borehole IDs was obtained. Filename prefix and parent-tray parsing is only a sampling heuristic.",
    "checkedAt": "2026-11-15",
    "sourcePaper": "https://www.sciencedirect.com/science/article/pii/S0920410520309888#sec2"
  },
  "humanVisualReview": {
    "status": "pending",
    "reviewer": null,
    "note": "Published lithology classes derive from source geologist logs; they do not provide independently reviewed visible-feature references for this evaluation."
  },
  "sourceImagesFrozenAt": "2026-11-15T07:41:57.626968+00:00",
  "rawImageTotalBytes": 455925
}
`,Oe="core-webgpu-pilot-2",V=new URL("./core-benchmark-v026/",location.href),m=[],X=new Set;let u,M,S=!1,L=!1,p,ce=0,P,A,de,le;const J="geomodel3d:qwen-benchmark:last-report";let Y="",R,v,D=0;const Ne=new Date().toISOString(),Ie=document.querySelector("#benchmark-app");Ie.innerHTML=`<main class="bench-shell"><nav class="bench-nav" aria-label="Benchmark navigation"><a class="bench-brand" href="./">GeoModel3D <span class="bench-version"></span></a><a href="./">Back to the ground model</a></nav>
<header class="bench-hero"><p class="bench-eyebrow">Experimental evaluation</p><h1>Test Qwen on your device</h1><p class="bench-lead">Run the same published core-image cases locally, then export what happened.</p><p>The model describes visible features. Human review is still pending, and no result changes your ground model, logs or engineering properties.</p></header>
<div class="bench-grid"><section class="bench-card" aria-labelledby="benchmark-run-heading"><h2 id="benchmark-run-heading">Run a device check</h2><p class="bench-support" id="benchmark-support" role="status">Checking this browser’s WebGPU support…</p>
<div class="bench-fields"><label>Purpose<select id="benchmark-mode"><option value="quality">Description evaluation · 128 tokens</option><option value="compatibility">Compatibility check · 32 tokens</option></select></label><label>Cases<select id="benchmark-count"><option value="1">One case</option><option value="5">First five cases</option><option value="40">All forty cases</option></select></label><label class="wide" id="benchmark-case-label">Selected case<select id="benchmark-case" disabled><option>Loading case IDs…</option></select></label><label class="wide">Device label (optional)<input id="benchmark-device" maxlength="120" placeholder="For example, iPhone 17 · Safari" autocomplete="off"><span class="bench-hint">Your label is recorded as self-reported, separately from browser information.</span></label></div>
<p class="bench-hint" id="benchmark-mode-note">The full study contains 40 cases. A smaller run is a partial evaluation; human assessment is required.</p>
<label class="bench-consent"><input id="benchmark-consent" type="checkbox"><span>I understand that starting may download about <strong>1.0 GiB</strong> of model weights, plus runtime and selected image files. Processing stays on this device.</span></label>
<div class="bench-actions"><button id="benchmark-run" class="primary" type="button" disabled>Download model &amp; run</button><button id="benchmark-stop" type="button" disabled>Stop &amp; unload</button></div>
<p id="benchmark-status" class="bench-status" role="status" aria-live="polite">No model or case image has been downloaded.</p><progress id="benchmark-progress" class="bench-progress" hidden aria-label="Current case progress"></progress>
<p class="bench-memory-note">Keep this page visible during a run. Switching apps or hiding the page stops the batch and preserves an interrupted result. Results are saved locally when browser storage permits. Export JSON for a durable copy.</p></section>
<aside class="bench-card bench-review" aria-labelledby="benchmark-review-heading"><h2 id="benchmark-review-heading">Keep the evidence</h2><ol><li>Complete the blank reference sheet with a geologist <strong>before viewing model answers</strong>.</li><li>Run the selected cases. A compatibility check tests execution only and is never counted as a quality score.</li><li>Export results, including failed, stopped and unstarted cases. Review descriptions against the photographs before judging usefulness.</li></ol>
<div class="bench-actions"><button id="benchmark-review-images" type="button" disabled>Review source images</button><button id="benchmark-review-csv" type="button" disabled>Download blank review sheet</button><button id="benchmark-export" type="button" disabled>Export results JSON</button><button id="benchmark-clear-cache" type="button">Clear benchmark downloads</button></div><p id="benchmark-recovery-status" role="status"></p><button id="benchmark-forget-report" type="button" disabled>Forget saved benchmark results</button><p id="benchmark-dataset-status">Loading the frozen case manifest…</p><p>These public patches do not establish borehole independence or engineering-property accuracy. GPU memory cannot be measured by this page; any available JavaScript heap value is reported separately.</p></aside></div>
<section id="benchmark-reference-panel" class="bench-card bench-reference" aria-labelledby="benchmark-reference-heading" hidden><div class="bench-reference-heading"><h2 id="benchmark-reference-heading">Image-only reference review</h2><button id="benchmark-reference-close" type="button">Close source review</button></div><p id="benchmark-reference-note">Describe the visible colour, texture, markings, edges and uncertainty in the blank review sheet. Save and freeze that reference before viewing model answers. No model runs from this panel.</p><div class="bench-reference-controls"><label>Source case<select id="benchmark-reference-case" aria-label="Source case"></select></label><button id="benchmark-reference-next" type="button">Next source image</button></div><div id="benchmark-reference-preview" aria-live="polite"></div></section>
<section class="bench-results" aria-labelledby="benchmark-results-heading"><h2 id="benchmark-results-heading">Run history</h2><div id="benchmark-results"><p class="bench-empty">No runs yet. Starting another run keeps earlier results in this page.</p></div></section>
<footer class="bench-footer"><div class="bench-links"><a href="https://github.com/kilickursat/GeoModel3D/tree/main/docs/benchmarks/0.26.0-core-ai" target="_blank" rel="noreferrer">Study protocol and source credits</a><a href="https://github.com/kilickursat/GeoModel3D/blob/main/docs/benchmarks/0.26.0-core-ai/NOTICE.md" target="_blank" rel="noreferrer">Image licence</a></div><p>Qwen3.5 0.8B · pinned Hugging Face model · local WebGPU. Model weights are separate from this page. Cached files may be evicted by your browser.</p></footer></main>`;const d=e=>document.getElementById(e);d("benchmark-app").querySelector(".bench-version").textContent=`${ee.version}`;const he=d("benchmark-run"),pe=d("benchmark-stop"),ue=d("benchmark-export"),fe=d("benchmark-review-csv"),me=d("benchmark-clear-cache"),B=d("benchmark-consent"),F=d("benchmark-review-images"),C=d("benchmark-reference-case"),U=d("benchmark-reference-next"),O=d("benchmark-mode"),N=d("benchmark-count"),I=d("benchmark-case"),ge=d("benchmark-device"),Z=d("benchmark-status"),y=d("benchmark-progress"),H=d("benchmark-results");function k(){return new Date().toISOString()}function q(){const e=performance.memory?.usedJSHeapSize;return typeof e=="number"&&Number.isFinite(e)&&e>=0?e:null}function be(){return{observedAt:k(),userAgent:navigator.userAgent,language:navigator.language,hardwareConcurrency:navigator.hardwareConcurrency??null,deviceMemoryGiB:navigator.deviceMemory??null,viewport:{width:innerWidth,height:innerHeight,pixelRatio:devicePixelRatio},physicalDeviceVerified:!1}}function je(){if(!(!u||!A||!m.length))try{const e=JSON.stringify({version:1,protocolSha256:A,manifestSha256:M,runs:m});if(e.length>2e6)throw new Error("Report exceeds local recovery storage size.");localStorage.setItem(J,e),d("benchmark-recovery-status").textContent=Y+"Results saved in this browser. Export JSON to keep a separate copy."}catch{d("benchmark-recovery-status").textContent="Local recovery storage is unavailable or full. Export JSON before closing this page."}}function Ve(){try{const e=localStorage.getItem(J);if(!e)return;if(e.length>2e6)throw new Error("Oversized recovery data.");const n=JSON.parse(e);if(n.version!==1||n.protocolSha256!==A||n.manifestSha256!==M||!Array.isArray(n.runs)||n.runs.length>100)throw new Error("Saved study differs from this study.");const t=a=>{if(typeof a!="string"||a.length>32||!Number.isFinite(Date.parse(a)))throw new Error("Invalid saved timestamp.");return a},r=a=>{if(a!==null&&(typeof a!="number"||!Number.isFinite(a)||a<0))throw new Error("Invalid saved measurement.");return a},s=(a,o)=>{if(typeof a!="string"||a.length>o)throw new Error("Invalid saved text.");return a},i=n.runs.map((a,o)=>{if(!a||!["quality","compatibility"].includes(a.mode)||a.maxNewTokens!==j(a.mode)||!Array.isArray(a.selectedCaseIds)||![1,5,40].includes(a.selectedCaseIds.length)||new Set(a.selectedCaseIds).size!==a.selectedCaseIds.length||!Array.isArray(a.cases)||a.cases.length!==a.selectedCaseIds.length||!["running","completed","failed","cancelled","interrupted"].includes(a.status))throw new Error("Invalid saved run.");const h=a.selectedCaseIds.map(c=>{if(!u.cases.some(_=>_.id===c))throw new Error("Invalid saved case.");return c}),f=a.cases.map((c,_)=>{const w=u.cases.find(we=>we.id===h[_]);if(c.caseId!==w.id||c.imageSha256!==w.sha256||c.sourceSha256!==w.sourceSha256||!["not-started","running","completed","failed","timed-out","cancelled","interrupted"].includes(c.status))throw new Error("Saved input does not match this study.");const z=c.result?ie(c.result,{caseId:w.id,expectedSha256:w.sha256,mode:a.mode,image:""}):void 0;if(c.status==="completed"!=!!z)throw new Error("Incomplete saved result.");const G=c.status==="running";return{caseId:w.id,imageSha256:w.sha256,sourceSha256:w.sourceSha256,status:G?"interrupted":c.status,...c.startedAt?{startedAt:t(c.startedAt)}:{},...G?{finishedAt:k(),error:"Run interrupted before this page reopened; no automatic retry."}:c.finishedAt?{finishedAt:t(c.finishedAt)}:{},...!G&&c.error?{error:s(c.error,16384)}:{},...c.elapsedMs!==void 0?{elapsedMs:r(c.elapsedMs)}:{},...z?{result:z}:{}}});if(a.status==="completed"&&f.some(c=>c.status!=="completed"))throw new Error("Saved completion count is inconsistent.");let l;if(a.browserContext){const c=a.browserContext;l={observedAt:t(c.observedAt),userAgent:s(c.userAgent,2048),language:s(c.language,64),hardwareConcurrency:r(c.hardwareConcurrency),deviceMemoryGiB:r(c.deviceMemoryGiB),viewport:{width:r(c.viewport.width),height:r(c.viewport.height),pixelRatio:r(c.viewport.pixelRatio)},physicalDeviceVerified:!1}}return{id:`run-${o+1}`,startedAt:t(a.startedAt),...a.status==="running"?{finishedAt:k()}:a.finishedAt?{finishedAt:t(a.finishedAt)}:{},mode:a.mode,maxNewTokens:a.maxNewTokens,status:a.status==="running"?"interrupted":a.status,selfReportedDeviceLabel:s(a.selfReportedDeviceLabel,120),physicalDeviceVerified:!1,cohortCaseCount:40,selectedCaseIds:h,unselectedCaseIds:u.cases.filter(c=>!h.includes(c.id)).map(c=>c.id),cases:f,mainThreadJsHeapBeforeBytes:r(a.mainThreadJsHeapBeforeBytes),...a.mainThreadJsHeapAfterBytes!==void 0?{mainThreadJsHeapAfterBytes:r(a.mainThreadJsHeapAfterBytes)}:{},pageVisibleAtStart:a.pageVisibleAtStart===!0,...a.preflightAdapter?{preflightAdapter:re({info:a.preflightAdapter,features:a.preflightAdapter.features,limits:a.preflightAdapter.limits})}:{},...l?{browserContext:l}:{},...a.status==="running"?{stopReason:"Recovered interrupted run; no automatic retry."}:a.stopReason?{stopReason:s(a.stopReason,16384)}:{}}});m.push(...i),Y=`Recovered ${i.length} saved run${i.length===1?"":"s"}; no automatic restart. `,b(`Recovered ${i.length} saved run${i.length===1?"":"s"}. No model was started; export or begin a new run explicitly.`)}catch{d("benchmark-recovery-status").textContent="Saved results could not be restored for this study. No model was started and the saved record was left unchanged."}}function b(e,n=!1){Z.textContent=e,Z.dataset.error=String(n)}function g(){he.disabled=!!p||L||!S||!u||!A||!B.checked,d("benchmark-forget-report").toggleAttribute("disabled",!!p||!m.length),pe.disabled=!p,me.disabled=!!p||L,ue.disabled=!m.length,fe.disabled=!u,F.disabled=C.disabled=U.disabled=!!p||!u,u&&C.value===u.cases.at(-1)?.id&&(U.disabled=!0);for(const e of[O,N,I,ge,B])e.disabled=!!p||L;u||(I.disabled=!0),d("benchmark-case-label").hidden=N.value!=="1",d("benchmark-mode-note").textContent=O.value==="compatibility"?"Compatibility mode stops at 32 tokens. Its output is unscored and does not establish description quality.":"The full study contains 40 cases. A smaller run is a partial evaluation; human assessment is required."}async function x(e){if(!crypto?.subtle)throw new Error("Secure image hashing is unavailable. Use HTTPS or localhost.");return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",e))).map(n=>n.toString(16).padStart(2,"0")).join("")}async function $(e,n,t){if(e.origin!==location.origin)throw new Error("Benchmark inputs must come from this site.");const r=await fetch(e,{signal:t,credentials:"omit",redirect:"error",referrerPolicy:"no-referrer"});if(!r.ok)throw new Error(`Could not load the benchmark input (HTTP ${r.status}).`);const s=Number(r.headers.get("Content-Length"));if(Number.isFinite(s)&&s>n)throw await r.body?.cancel(),new Error("Benchmark input exceeds its size limit.");const i=r.body?.getReader();if(!i)throw new Error("This browser cannot read benchmark inputs.");const a=[];let o=0;try{for(;;){const l=await i.read();if(l.done)break;if(o+=l.value.length,o>n)throw new Error("Benchmark input exceeds its size limit.");a.push(l.value)}}catch(l){throw await i.cancel().catch(()=>{}),l}finally{i.releaseLock()}const h=new Uint8Array(o);let f=0;for(const l of a)h.set(l,f),f+=l.length;return h}function Me(e){const n=JSON.parse(new TextDecoder().decode(e));if(n.version!==1||n.datasetId!=="core-v026"||!Array.isArray(n.cases)||n.cases.length!==40)throw new Error("The study manifest does not contain the fixed forty cases.");return{version:1,datasetId:"core-v026",cases:n.cases.map((r,s)=>{const i=`case-${String(s+1).padStart(2,"0")}`;if(r.id!==i||r.image!==`images/${i}.png`||!/^([a-f0-9]{64})$/.test(r.sha256)||!/^([a-f0-9]{64})$/.test(r.sourceSha256)||r.width!==512||r.height!==512)throw new Error("The study manifest has an invalid case, image path or source hash.");return{id:i,image:r.image,sha256:r.sha256,sourceSha256:r.sourceSha256,width:512,height:512}})}}function ze(e){let n="";for(let t=0;t<e.length;t+=32768)n+=String.fromCharCode(...e.subarray(t,t+32768));return`data:image/png;base64,${btoa(n)}`}function Q(e=!1){D++,R?.abort(),R=void 0,v&&(URL.revokeObjectURL(v),v=void 0),d("benchmark-reference-preview").replaceChildren(),d("benchmark-reference-panel").hidden=!0,e&&F.focus()}async function K(){if(p||!u)return;const e=u.cases.find(s=>s.id===C.value);if(!e)return;R?.abort();const n=new AbortController;R=n;const t=++D;v&&(URL.revokeObjectURL(v),v=void 0),d("benchmark-reference-panel").hidden=!1;const r=d("benchmark-reference-preview");r.textContent=`Loading and verifying ${e.id}…`,d("benchmark-reference-note").textContent=m.some(s=>s.cases.some(i=>i.result))?"Model answers have already been displayed in this page. Record that exposure honestly in the review sheet; this is not a reference prepared before seeing outputs. No model runs from this panel.":"Describe the visible colour, texture, markings, edges and uncertainty in the blank review sheet. Save and freeze that reference before viewing model answers. No model runs from this panel.",g();try{const s=await $(new URL(e.image,V),21e5,n.signal);if(D!==t)return;if(await x(s)!==e.sha256)throw new Error("The source image does not match its frozen hash.");if(D!==t)return;v=URL.createObjectURL(new Blob([s],{type:"image/png"}));const i=document.createElement("img");i.src=v,i.alt=`Frozen source image ${e.id}; no model interpretation`,i.width=i.height=512;const a=document.createElement("p");a.textContent=`${e.id} · verified 512 × 512 input. The patch is enlarged from the source; enlargement adds no observed detail.`,r.replaceChildren(i,a)}catch(s){D===t&&(r.textContent=s instanceof Error?s.message:String(s))}}function T(){if(je(),!m.length){H.textContent="No runs yet.";return}H.replaceChildren();for(let e=m.length-1;e>=0;e--){const n=m[e],t=document.createElement("article");t.className="bench-run",t.dataset.runId=n.id;const r=document.createElement("h3");r.textContent=`Run ${e+1} · ${n.mode==="quality"?"Description evaluation":"Compatibility check"}`,t.append(r);const s=document.createElement("p");s.className="bench-run-summary";const i=n.cases.filter(a=>a.status==="completed").length;s.textContent=`${i}/${n.cases.length} selected cases completed · ${n.status} · full study: 40 cases. ${n.mode==="compatibility"?"Unscored execution check.":"Human quality review pending."}`,t.append(s);for(const a of n.cases){const o=document.createElement("section");o.className="bench-case",o.dataset.caseId=a.caseId;const h=document.createElement("div");h.className="bench-case-head";const f=document.createElement("h4");f.textContent=a.caseId;const l=document.createElement("span");if(l.className="bench-case-status",l.dataset.status=a.status,l.textContent=a.status.replaceAll("-"," "),h.append(f,l),o.append(h),a.result){const c=document.createElement("div");c.className="bench-answer",c.textContent=a.result.text,o.append(c);const _=document.createElement("p");_.className="bench-case-meta",_.textContent=`${a.result.generatedTokens}/${a.result.maxNewTokens} tokens · ${(a.result.inferenceMs/1e3).toFixed(1)} s generation${a.result.outputLimitReached?" · output limit reached; answer may be incomplete":""}. Unreviewed model output.`,o.append(_)}if(a.error){const c=document.createElement("p");c.textContent=a.error,o.append(c)}t.append(o)}H.append(t)}}function Ge(e,n,t){p===e&&(b(`${n.caseId} · ${t.message}`),y.hidden=!1,t.phase==="loading"&&t.total&&t.loaded!==void 0?(y.max=t.total,y.value=Math.min(t.loaded,t.total)):t.generatedTokens!==void 0&&t.maxNewTokens?(y.max=t.maxNewTokens,y.value=t.generatedTokens):y.removeAttribute("value"))}function E(e,n){const t=p;t&&(p=void 0,ce++,clearTimeout(t.caseTimer),t.abort.abort(),t.client.dispose(),t.run.status=n==="timed-out"?"failed":n,t.run.finishedAt=k(),t.run.stopReason=e,t.run.mainThreadJsHeapAfterBytes=q(),t.current?.status==="running"&&(t.current.status=n,t.current.finishedAt=k(),t.current.elapsedMs=performance.now()-(t.currentStarted??performance.now()),t.current.error=e),y.hidden=!0,b(`${e} Completed and unstarted cases are preserved. Export this page’s results before closing.`),T(),g())}async function He(){if(p||L||!u||!A||!S||!B.checked)return;const e=O.value,n=Number(N.value),t=n===1?u.cases.filter(i=>i.id===I.value):u.cases.slice(0,n);if(![1,5,40].includes(n)||t.length!==n){b("Choose a valid set of frozen cases.",!0);return}if(document.visibilityState!=="visible"){b("Keep this page visible before starting a run.",!0);return}Q();const r={id:`run-${m.length+1}`,startedAt:k(),mode:e,maxNewTokens:j(e),status:"running",selfReportedDeviceLabel:ge.value.trim().slice(0,120),physicalDeviceVerified:!1,cohortCaseCount:40,selectedCaseIds:t.map(i=>i.id),unselectedCaseIds:u.cases.filter(i=>!t.some(a=>a.id===i.id)).map(i=>i.id),cases:t.map(i=>({caseId:i.id,imageSha256:i.sha256,sourceSha256:i.sourceSha256,status:"not-started"})),mainThreadJsHeapBeforeBytes:q(),pageVisibleAtStart:!0,browserContext:be(),...P?{preflightAdapter:structuredClone(P)}:{}},s={token:++ce,run:r,abort:new AbortController,client:new De};p=s,m.push(r),T(),g();try{for(let i=0;i<t.length;i++){if(p!==s)return;const a=t[i],o=r.cases[i];s.current=o,s.currentStarted=performance.now(),o.status="running",o.startedAt=k(),s.caseTimer=setTimeout(()=>E("This case timed out after its thirty-minute budget; remaining cases were not started.","timed-out"),W),T(),b(`${a.id} · Loading the frozen image from this site…`);try{const h=await $(new URL(a.image,V),21e5,s.abort.signal);if(p!==s)return;if(await x(h)!==a.sha256)throw new Error("Image integrity check failed. No model was started for this case.");if(p!==s)return;const f=await s.client.run({caseId:a.id,image:ze(h),expectedSha256:a.sha256,mode:e},l=>Ge(s,o,l));if(p!==s)return;o.result=f,o.status="completed",o.finishedAt=k(),o.elapsedMs=performance.now()-s.currentStarted,clearTimeout(s.caseTimer),T()}catch(h){if(p!==s)return;o.error=h instanceof Error?h.message:String(h),o.status=/timed out/i.test(o.error)?"timed-out":"failed",o.finishedAt=k(),o.elapsedMs=performance.now()-s.currentStarted,clearTimeout(s.caseTimer),r.status="failed",r.stopReason="Stopped at the first failed case; later selected cases were not started.",b(`${a.id} failed. ${o.error} Later cases remain unstarted.`,!0);break}}if(p!==s)return;r.status==="running"&&(r.status="completed",b(`${r.cases.length} selected case${r.cases.length===1?"":"s"} completed. ${e==="compatibility"?"Compatibility output is unscored.":"Human quality review is still pending."} Export your results.`)),r.finishedAt=k(),r.mainThreadJsHeapAfterBytes=q()}finally{clearTimeout(s.caseTimer),s.client.dispose(),p===s&&(p=void 0,y.hidden=!0,T(),g())}}function ke(e,n,t){const r=URL.createObjectURL(new Blob([t],{type:n}));X.add(r);const s=document.createElement("a");s.href=r,s.download=e,document.body.append(s),s.click(),s.remove(),setTimeout(()=>{URL.revokeObjectURL(r),X.delete(r)},6e4)}function We(){if(!u||!m.length)return;const e={format:"geomodel3d-core-device-benchmark",version:1,appVersion:ee.version,createdAt:Ne,exportedAt:k(),partial:!!p,protocol:{id:Oe,sha256:A,rubricSha256:de,sourceManifestSha256:le,promptVersion:se,prompt:ae,model:ne,qualityTokenLimit:128,compatibilityTokenLimit:32,doSample:!1,repetitionPenalty:1.1,humanReviewStatus:"pending",qualityScores:null},dataset:{id:u.datasetId,manifestSha256:M,cohortCaseCount:40,boreholeIndependence:"unverified",cases:u.cases.map(n=>({caseId:n.id,imageSha256:n.sha256,sourceSha256:n.sourceSha256,width:n.width,height:n.height}))},browser:be(),memory:{gpuMemoryBytes:null,note:"Main-thread and worker JavaScript heap observations, when available, exclude GPU allocations. They do not measure total model or device memory."},methodology:"Each selected case runs once in recorded order with the pinned model, frozen input hash and fixed prompt. Stop, failure or page hiding preserves completed/current/unstarted records. Runs are not retried automatically. Compatibility output is excluded from quality evaluation. Human references and scores must be supplied independently; no quality or engineering accuracy is inferred from execution.",runs:structuredClone(m)};ke(`geomodel3d-qwen-device-${new Date().toISOString().replaceAll(":","-")}.json`,"application/json",JSON.stringify(e,null,2)+`
`)}function Ue(){if(!u)return;const e=o=>'"'+o.replaceAll('"','""')+'"',n=Pe.trimEnd().split(/\r?\n/),t=n[0].split(","),r=t.indexOf("case_id"),s=t.indexOf("image_path"),i=t.indexOf("image_sha256");if(r<0||s<0||i<0||n.length!==41)throw new Error("The human review template does not match the forty-case protocol.");const a=u.cases.map((o,h)=>{const f=n[h+1].split(",");if(f.length!==t.length||f[r]!==o.id)throw new Error("The human review template case order changed.");return f[s]=new URL(o.image,V).href,f[i]=o.sha256,f.map(e).join(",")});ke("geomodel3d-core-v026-blank-reference-review.csv","text/csv;charset=utf-8",[t.map(e).join(","),...a].join(`\r
`)+`\r
`)}he.addEventListener("click",()=>{He().catch(e=>b(e instanceof Error?e.message:String(e),!0))});pe.addEventListener("click",()=>E("Stopped by the user.","cancelled"));ue.addEventListener("click",We);fe.addEventListener("click",Ue);F.addEventListener("click",()=>{K(),d("benchmark-reference-heading").scrollIntoView({block:"start"})});C.addEventListener("change",()=>{K()});U.addEventListener("click",()=>{C.selectedIndex<C.options.length-1&&(C.selectedIndex++,K())});d("benchmark-reference-close").addEventListener("click",()=>Q(!0));for(const e of[B,O,N])e.addEventListener("change",g);me.addEventListener("click",()=>{p||L||(L=!0,g(),xe().then(e=>b(e?"Cached benchmark model downloads removed. Other GeoModel3D data are unchanged.":"No benchmark model cache was present.")).catch(e=>b(e instanceof Error?e.message:String(e),!0)).finally(()=>{L=!1,g()}))});d("benchmark-forget-report").addEventListener("click",()=>{if(!p)try{localStorage.removeItem(J),Y="",m.length=0,T(),g(),d("benchmark-recovery-status").textContent="Saved benchmark results removed. Model cache and ground-model data are unchanged."}catch{d("benchmark-recovery-status").textContent="Browser storage could not remove the saved benchmark report."}});document.addEventListener("visibilitychange",()=>{document.visibilityState!=="visible"&&E("Page hidden; the batch was interrupted and the model unloaded.","interrupted")});window.addEventListener("pagehide",()=>{E("Page left; the batch was interrupted and the model unloaded.","interrupted"),Q()});window.addEventListener("beforeunload",e=>{p&&(E("Page closed or reloaded; the batch was interrupted.","interrupted"),e.preventDefault(),e.returnValue="")});oe().then(e=>{S=e.supported,P=e.adapter;const n=d("benchmark-support");n.dataset.state=S?P?.softwareAdapter?"software":"available":"unavailable",n.textContent=S?P?.softwareAdapter?"A software WebGPU adapter is active. Runs may take a long time and do not measure hardware GPU or phone speed.":"WebGPU is available. No model downloads until you start. Adapter identity may be hidden by the browser.":e.reason??"WebGPU is unavailable. You can still prepare a human reference sheet.",g()}).catch(e=>{S=!1,d("benchmark-support").textContent=e instanceof Error?e.message:String(e),d("benchmark-support").dataset.state="unavailable",g()});$(new URL("manifest.json",V),128e3).then(async e=>{const n=Me(e),t=new TextEncoder,[r,s,i,a]=await Promise.all([x(e),x(t.encode(Ee)),x(t.encode(Re)),x(t.encode(Be))]);u=n,M=r,A=s,de=i,le=a,I.replaceChildren(...n.cases.map(o=>new Option(o.id,o.id))),C.replaceChildren(...n.cases.map(o=>new Option(o.id,o.id))),d("benchmark-dataset-status").textContent="40 frozen public images are available. Case images load only when you review a source or start a run.",Ve(),T(),g()}).catch(e=>{d("benchmark-dataset-status").textContent=`Case manifest unavailable: ${e instanceof Error?e.message:String(e)}`,b("The frozen image set could not be verified. No model or case image was downloaded.",!0),g()});g();
